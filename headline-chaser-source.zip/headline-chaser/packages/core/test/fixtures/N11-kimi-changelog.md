> ## Documentation Index
> Fetch the complete documentation index at: https://platform.kimi.com/docs/llms.txt
> Use this file to discover all available pages before exploring further.

# 平台新功能发布记录

> 查看 Kimi 开放平台的历史功能发布、模型上线、产品优化与问题修复记录。

本文不定期更新 Kimi 开放平台的产品功能和对应的文档动态。

**2026年10月**

### 📦 Batch API 支持 Kimi K3.1 Pro 与 Kimi K3

Batch API 批量推理新增支持 `kimi-k3.1-pro` 和 `kimi-k3` 模型（此前仅支持 `kimi-k2.7-code` 与 `kimi-k2.6`），国内外同步上线。批量推理价格仍为标准价格的 60%；其中 `kimi-k3.1-pro`、`kimi-k3` 的批量任务同样收取缓存写入（Cache Write）费用，且由于批处理请求为异步并发处理，缓存命中为尽力而为。详见 [Batch API 指南](https://platform.kimi.com/docs/guide/use-batch-api.md) 与 [批量推理定价](https://platform.kimi.com/docs/pricing/batch.md)。

**2026年9月**

### 🤖 Kimi 托管智能体（Hosted Agents）Beta 上线

在模型推理 API 之上，我们封装了 Kimi Durable Harness，为企业提供 7x24 小时全托管的智能体运行环境——无需自建沙箱与会话基础设施，就能让 Agent 高质量、可持续地执行长程任务。

* **开箱即用的 Harness**：会话历史、工具执行、沙箱、失败恢复、超时重试全部由平台托管，你只需关注任务本身
* **控制台 + API + kha CLI 三种用法**：网页上快速体验，API 集成进自有系统，或在终端用自然语言初始化智能体
* **多智能体编排**：支持子智能体委派与协作，把复杂任务拆成「调研 + 编码 + 测试」等多角色流水线
* **技能、插件与凭据库**：挂载版本化技能包、官方插件，通过凭据库安全注入第三方服务凭据
* **记忆与梦境**：跨会话持久化记忆，平台自动整理关键信息，Agent 用得越多越懂你的项目

Beta 版当前面向国内企业认证用户开放。详见 [托管智能体快速开始](https://platform.kimi.com/docs/hosted-agents/quickstart.md)、[使用控制台](https://platform.kimi.com/docs/hosted-agents/console.md)、[托管智能体定价](https://platform.kimi.com/docs/pricing/hosted-agents.md)。

### 🔍 联网搜索 API

通过 `/v1/tools/search` 与 `/v1/tools/search_pro` 发起网页搜索，返回结构化搜索结果，适用于需要自行编排搜索逻辑的 Agent 应用；支持组织/项目级搜索 QPS 限额配置。详见 [联网搜索 Basic](https://platform.kimi.com/docs/api/tools-search.md)、[联网搜索 Pro](https://platform.kimi.com/docs/api/tools-search-pro.md)、[联网搜索最佳实践](https://platform.kimi.com/docs/guide/best-practices-for-web-search.md)、[联网搜索定价](https://platform.kimi.com/docs/pricing/websearch.md)。

### 💰 计费方式调整

账户消耗按现金、代金券各 50% 的统一比例扣除；当其中一类用尽时，后续消耗全额从另一类扣除；已签署合同的用户以合同约定为准，继续优先消耗代金券。

**2026年8月**

* `kimi-k2.5` 与 `moonshot-v1` 全系列模型（含 `-vision-preview`、`moonshot-v1-auto`）在国内外全平台下线，调用将返回 404 错误，请迁移至 [Kimi K3](https://platform.kimi.com/docs/guide/kimi-k3-quickstart.md)
* Files API 更新：新生成的文件 ID 统一添加 `file_` 前缀；提升文档解析效果，优化表格、公式等复杂内容的解析；不再对图片进行 OCR 文本提取，图片理解请使用 `purpose=image` 上传图片（详见 [使用视觉模型](https://platform.kimi.com/docs/guide/use-kimi-vision-model.md)）；上传的文件与已有文件同名时，服务端自动为新文件重命名

**2026年7月**

### 🚀 Kimi K3 上线开放平台 API

Kimi 面向长程编程与端到端知识工作的旗舰模型 K3 正式通过开放平台 API 提供，1M token 上下文，综合智能达到领先水平。详见 [Kimi K3 快速开始](https://platform.kimi.com/docs/guide/kimi-k3-quickstart.md)。同期 `kimi-k2.5` 和 `moonshot-v1` 系列停止向新注册用户开放。账户概览新增当日实时消费金额展示，平台服务协议同步更新。

**2026年6月**

* 支持组织级 API IP 白名单配置，企业安全管控更精细
* Kimi K2.7 Code 正式上线开放平台 API，随后推出高速版，详见 [Kimi K2.7 Code 快速开始](https://platform.kimi.com/docs/guide/kimi-k2-7-code-quickstart.md)

**2026年5月**

* `kimi-k2` 系列模型（含 `kimi-k2-0905-preview`、`kimi-k2-0711-preview`、`kimi-k2-turbo-preview`、`kimi-k2-thinking`、`kimi-k2-thinking-turbo`）正式下线，不再维护和支持，请使用最新模型 [Kimi K3](https://platform.kimi.com/docs/guide/kimi-k3-quickstart.md)

**2026年4月**

* Batch API 面向全量用户开放，大批量异步推理成本更低，详见 [使用 Batch API 批量处理任务](https://platform.kimi.com/docs/guide/use-batch-api.md)
* Kimi K2.6 发布并通过开放平台 API 提供，详见 [Kimi K2.6 快速开始](https://platform.kimi.com/docs/guide/kimi-k2-6-quickstart.md)

**2026年1月**

* Kimi K2.5 发布并通过开放平台 API 提供；`kimi-latest` 模型正式下线

**2025年11月**

* Kimi K2 Think 及其 Turbo 版本发布，提升各 Tier 默认 TPM 并降低 Kimi Turbo 系列价格；`kimi-thinking-preview` 模型正式下线

**2025年10月**

* 更新 Kimi CLI 和 K2 快速开始文档，结束 Kimi Turbo 五折活动，补充 K2VV 及销售入口，并下线手动 Cache 展示功能

**2025年9月**

* kimi-k2-0905-preview 模型上线

**2025年8月**

* Kimi K2 高速版 `kimi-k2-turbo-preview` 发布

**2025年7月**

* Kimi K2 模型 `kimi-k2-0711-preview` 发布；Kimi Playground 发布并支持流式输出、第三方及 ModelScope MCP Server 配置；官方 Formula Tools 支持通过 API 调用

**2025年5月**

* Kimi 思考模型 `kimi-thinking-preview` 发布

**2025年4月**

* 模型产品降价；支持组织成员邀请/管理功能；修复创建项目时名称框光标移动失败问题

**2025年2月**

* kimi-latest 模型上线；支持组织月账单导出；修正项目限速显示问题；支持项目日/月消费预警

**2025年1月**

* moonshot-v1-vision-preview 模型上线；支持组织项目管理功能；微信支付二维码恢复上线；支持海外手机号注册登录

**2024年12月**

* 优化资源管理列表复制样式为鼠标悬浮点击；优化资源列表按上传时间由近及远排序；支持一个企业实体认证多账号；修复发票退票失败问题

**2024年11月**

* Context Caching 功能放开给全量用户，Cache 续期不再收取创建费用；文档中心增加条款与协议内容显示；修复支付成功后前端频闪、发票退票失败、修改删除 APIKey 等问题

**2024年9月**

* File 文件资源管理前端功能支持；换绑手机号前端分两步验证；验证码短信内容中加验证码用途说明；修复可开票金额显示错误、发票税号空格导致开票失败等问题；企业认证增加银行打款受理时间显示；增加自动断线重连操作文档说明；上线联网搜索功能

**2024年8月**

* moonshot-v1-auto 上线；帐户余额自定义预警支持；手机号换绑功能支持；账号密码登陆支持；Cache 存储费用降低；MoonPalace 使用指南文档发布；Kimi 企业级 API 发布；用户基本信息增加 tier 等级显示

**2024年7月**

* Context Caching 开启公测并逐步扩大范围，补充实践文档和开发者社群入口；Kimi API 调试工具 MoonPalace 发布，用户消费分析及组织认证能力上线

**2024年6月**

* 企微客服二维码上线；API Key 个数限制优化；Kimi API 助手实践 Context Caching 第一篇 Blog 发布；发布用得起的长文本 Blog 发布；代金券有限期支持

**2024年5月**

* Blog 空间上线；开放平台 DarkMode 支持；发票管理功能上线；微信/支付宝扫码支付优化

**2024年4月**

* Tool Calling 功能上线；实名认证功能上线；公对公转账功能上线；微信/支付宝支付功能上线；余额监控接口支持
