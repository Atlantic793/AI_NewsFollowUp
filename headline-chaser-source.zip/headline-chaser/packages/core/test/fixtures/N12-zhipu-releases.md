> ## Documentation Index
> Fetch the complete documentation index at: https://docs.bigmodel.cn/llms.txt
> Use this file to discover all available pages before exploring further.

# 模型与产品发布记录

## 公告通知

**2026-08-26**

GLM-5.3-Flash 原生多模态模型上线

👀 [**GLM-5.3-Flash**](https://docs.bigmodel.cn/cn/guide/models/vlm/glm-5.3-flash.md)

* 原生融入视觉能力，使模型能够主动观察界面、渲染与交互反馈并持续迭代改进，实现代码、浏览器与图形界面的协同闭环。
* 极致高效混合架构：采用线性注意力与稀疏注意力混合架构（总参 320B，激活 18B），计算量与 KV 缓存较 GLM-5.3 大幅降低。
* 超越 Coding 的专业工作伙伴：拓展至 Office 文档与金融研究工作流，自主拆解复杂目标、调用工具、检查优化输出。

**2026-8-19**

GLM-5.3 新一代旗舰模型上线

💬 [**GLM-5.3**](https://docs.bigmodel.cn/cn/guide/models/text/glm-5.3.md)

* 更强的编程能力：GLM-5.3 的编程能力大幅提升，在智谱内部 Z.ai Code Bench 上较 GLM-5.2 提升了 50%，在包括 Terminal Bench 3.0 等公开基准测试中达到开源模型 SOTA 水平
* 涌现的网络安全能力：在白盒代码审查与漏洞发现持平 Mythos 5，已联合多个中国安全团队测试并累计发现 2436 个漏洞（1097 个中高危）

**2026-06-16**

GLM-5.2 新一代旗舰模型上线

💬 [**GLM-5.2**](https://docs.bigmodel.cn/cn/guide/models/text/glm-5.2.md)

* 支持 1M 无损上下文，长程任务能力显著提升，减少复杂任务中的上下文漂移与目标遗忘
* Coding 与长程任务评测达到开源 SOTA，在复杂系统工程、深度调试中表现更稳
* 真实开发体感显著提升，项目级上下文承载、工程规范遵循与多端开发更可靠

**2026-05-29**

GLM Coding Plan 团队版上线

🤝 [**GLM Coding Plan 团队版**](https://docs.bigmodel.cn/cn/coding-plan/team.md)

* 面向企业与开发团队的自助订阅方案上线，延续个人版高额模型用量，并兼容全球主流编码工具
* 支持席位、权限、用量与预算统一管理，帮助团队实现可追踪、可控制的 AI 编程协作
* 提供集中账单、统一开票与企业级数据安全保障，默认不将代码、提示词和对话内容用于模型训练
* 高级版支持首发接入最新旗舰模型及高峰期资源优先保障，带来更稳定高效的团队开发体验

**2026-04-07**

GLM-5.1 新一代旗舰模型上线

💬 [**GLM-5.1**](https://docs.bigmodel.cn/cn/guide/models/text/glm-5.1)

* Coding 能力大大增强，长程任务（Long Horizon Task）显著提升，支持一次任务中独立、持续工作长达 8 小时，实现从规划、执行到交付的完整闭环
* 在自主规划、持续执行、问题修复与策略迭代上展现更强的工程智能，能够完成更长链路的复杂任务闭环
* 综合能力全面对齐 Claude Opus 4.6，成为首个在综合能力上实现全面对齐的中国模型，并跻身全球开源模型前列
* 通过 multi-turn SFT、RL 与过程质量评估体系，进一步强化长任务中的稳定性、一致性与 tool use 能力

**2026-04-02**

GLM-5V-Turbo 多模态 Coding 基座模型上线

👀 [**GLM-5V-Turbo**](https://docs.bigmodel.cn/cn/guide/models/vlm/glm-5v-turbo)

* 兼顾视觉理解与 Coding 能力，在更小参数量下实现更优的性能表现，多模态任务处理更高效
* 细粒度理解、几何感知与空间理解能力进一步增强，复杂视觉推理更准确
* 强化 GUI Agent、Coding Agent 等复杂任务表现，更适合“看懂环境—规划动作—执行任务”的长流程场景
* 多模态工具链进一步扩展，在文本工具基础上新增支持画框、截图、读网页（含图片识别）等多模态 Tools

**2026-03-15**

GLM-5-Turbo 龙虾增强基座模型上线

🦞 [**GLM-5-Turbo**](https://docs.bigmodel.cn/cn/guide/models/text/glm-5-turbo)

* 面向 OpenClaw 龙虾场景深度优化的基座模型
* 强化了对外部工具与各类Skills的调用能力，在多步任务中更稳定、更可靠
* 复杂指令拆解更强，能够精准识别目标、规划步骤，并支持多智能体之间的协同分工
* 能够更好理解时间维度上的要求，在复杂长任务中保持执行连续性
* 针对数据吞吐量大、逻辑链条长的龙虾任务，进一步提升了执行效率与响应稳定性

**2026-02-12**

GLM-5 新一代旗舰模型上线

💬 [**GLM-5**](https://docs.bigmodel.cn/cn/guide/models/text/glm-5)

* 专为复杂系统工程与长程 Agent 任务设计，实现从代码到工程的范式跃迁
* 后端架构设计、复杂算法实现及顽固 Bug 修复上展现出卓越的深度推理能力
* 在代码逻辑密度和系统工程能力上直接对标 Claude Opus 4.5
* 首次集成 DeepSeek Sparse Attention，在维持长文本效果无损的同时，提升 Token Efficiency

**2026-02-03**

GLM-OCR 图文解析模型上线

👀 [**GLM-OCR**](https://docs.bigmodel.cn/cn/guide/models/vlm/glm-ocr.md)

* 采用自研 CogViT 与 GLM-0.5B 的编码器-解码器设计，连接层实现高效跨模态对齐
* 基于数十亿图文对的 CLIP 预训练，具备强大的视觉语义与关键 Token 提取能力
* 模型小、速度快，在手写体、表格、印章、竖排等复杂场景中表现稳定

**2026-01-19**

GLM-4.7-Flash 免费模型上线

💬 [**GLM-4.7-Flash**](https://docs.bigmodel.cn/cn/guide/models/free/glm-4.7-flash)

* 轻量参数规模下实现了高效的 Coding 能力，任务理解与代码生成能力处于同类模型的较高水平
* 通用能力同级别最优，在写作、翻译、推理、角色扮演、长文本与审美等核心场景下兼顾质量与响应速度
* 为 GLM-4.7 的免费版本，针对高频调用场景进行优化，显著降低使用门槛与成本

**2026-01-14**

GLM-Image 图像生成模型上线

📷 [**GLM-Image**](https://docs.bigmodel.cn/cn/guide/models/text/glm-4.7)

* 首个在国产芯片上完成全流程训练的 SOTA 多模态模型
* 采用「自回归理解 + 扩散解码」混合架构，模型能读懂指令、补全细节
* 知识密集型场景全面增强，文字渲染更稳更准（汉字尤其出色）

**2025-12-22**

GLM-4.7 基座模型上线

💬 [**GLM-4.7**](https://docs.bigmodel.cn/cn/guide/models/text/glm-4.7)

* Coding 能力全面提升，代码生成更稳、更完整，长代码与工程级场景下的一次性交付能力显著增强
* Agentic Coding 能力升级，支持以任务为中心的端到端开发
* 前端与视觉代码理解增强，生成页面在布局、交互与审美上更接近可展示、可直接使用的水平
* 通用对话与内容生成更可靠，复杂问题拆解更清晰，简单问题回应更直接，整体表达更自然、高效

**2025-12-11**

AutoGLM-Phone AI 手机智能助理框架上线

🤖 [**AutoGLM-Phone**](https://docs.bigmodel.cn/cn/guide/models/vlm/autoglm-phone)

* 支持用自然语言自动完成 App 操作任务
* 具备界面识别、意图规划与设备执行的端到端处理能力，无需人工点击或复杂配置
* 已适配 50+ 主流中文应用场景，覆盖购物、出行、外卖、影音、资讯等高频任务
* 支持完整操作指令集，包括启动 App、输入文字、滑动、点击、回退、长按等，实现细粒度交互控制

**2025-12-11**

GLM-TTS-Clone 音色克隆模型上线

🎵 [**GLM-TTS-Clone**](https://docs.bigmodel.cn/cn/guide/models/sound-and-video/glm-tts-clone)

* 只需录制约 3 秒清晰语音，即可生成专属音色
* 支持普通话及轻口音，更好复刻节奏、停顿、语气词等个性化表达
* 无论旁白、客服、剧情配音、教育讲解，均可保持音色统一与情感一致性
* 可与 GLM-TTS 联动，通过音色 ID 进行批量生产

**2025-12-11**

GLM-TTS 语音合成模型上线

🎵 [**GLM-TTS**](https://docs.bigmodel.cn/cn/guide/models/sound-and-video/glm-tts)

* 在架构上采用两阶段生成，在自然度、情绪表达与语调连贯性上实现全面升级
* 支持流式与非流式接口，首帧响应低于 400ms，实现低延迟的交互式体验
* 强化学习（GRPO）优化显著降低字错误率，并在开源评测中取得 SOTA 情感表达表现
* 支持灵活控制语速、音量与风格，满足客服、阅读、文旅、智能硬件等多场景需求

**2025-12-10**

GLM-ASR-2512 语音识别模型上线

🎤 [**GLM-ASR-2512**](https://docs.bigmodel.cn/cn/guide/models/sound-and-video/glm-asr-2512)

* 行业出色语音识别性能，最新评测字符错误率（CER）仅 0.0717
* 支持多语言与方言识别，覆盖普通话、粤语、四川话、美式/英式英语及数十种全球常用语言
* 原生支持自定义词典，可快速导入专业术语、人名地名与项目代号，显著提升垂直行业识别精度

**2025-12-08**

GLM-4.6V 视觉推理模型上线

👀 [**GLM-4.6V**](https://docs.bigmodel.cn/cn/guide/models/vlm/glm-4.6v)

* 20+ 主流多模态评测基准全面验证，均取得 SOTA 成绩
* 原生支持工具调用，具备强大的图文混排创作能力，并能处理识图购物等复杂的视觉任务
* 视觉上下文窗口扩展至 128k，可单次处理约 150 页的复杂文档、200 页 PPT 或一小时视频
* 针对前端开发场景深度调优，支持“截图即代码”，大幅提升 GLM Coding Plan 的开发与调试效率

**2025-09-30**

GLM-4.6 基座模型上线

💬 [**GLM-4.6**](https://docs.bigmodel.cn/cn/guide/models/text/glm-4.6)

* 在公开基准与真实编程任务中展现出更强的代码能力
* 上下文窗口扩展至200K，提升处理长代码与复杂智能体任务的能力
* 推理过程进一步优化，支持在推理过程中调用工具，提升智能体任务执行的灵活性与效率
* 加强了模型在工具调用和智能体框架下的表现，使其在多场景应用中更加高效

**2025-08-11**

GLM-4.5V 视觉推理模型上线

👀 [**GLM-4.5V**](https://docs.bigmodel.cn/cn/guide/models/vlm/glm-4.5v)

* 100B 级别开源视觉推理模型 SOTA，比 GLM-4.1V-Thinking “更大更强”
* 覆盖从视频理解、前端复刻、视觉定位、图像识别与推理，到复杂文档解析与 GUI Agent 等多场景的视觉任务
* 新增“思考模式”开关，可灵活选择快速响应或深度推理

**2025-07-28**

GLM-4.5 系列基座模型上线

💬 [**GLM-4.5**](https://docs.bigmodel.cn/cn/guide/models/text/glm-4.5)

* SOTA 级原生智能体大模型
* 参数效率翻倍，API 价格仅为 Claude 的1/10，极速版速度超 100tokens/秒
* 实测 Agentic Coding 表现优异，支持一键兼容 Claude Code 框架

**2025-07-15**

CogVideoX-3 视频生成模型上线

📺 [**CogVideoX-3**](https://docs.bigmodel.cn/cn/guide/models/video-generation/cogvideox-3)

* 新升级视频生成大模型，支持文生、图生视频
* 新增首尾帧生成功能
* 画面清晰度主观感受显著提升
* 主体大幅度运动自然流畅
* 提升了高清现实及 3D 风格场景表现

**2025-07-02**

GLM-4.1V-Thinking 系列视觉推理模型上线

👀 [**GLM-4.1V-Thinking**](https://docs.bigmodel.cn/cn/guide/models/vlm/glm-4.1v-thinking)

* 定位优势：通用视觉模型
* 核心能力：具备强大的多模态理解和推理能力
* 任务表现：在视频理解、图像问答、图表解读、图形界面操作等多任务项均达到新SOTA
* 能力特点：不止看得懂（基础视觉理解），更能想得透（深度推理能力）

**2025-06-18**

接入两个 Vidu 热门视频生成模型

📺 [**Vidu Q1**](https://docs.bigmodel.cn/cn/guide/models/video-generation/viduq1)

* 聚焦高质量视频创作
* 固定输出 5 秒、24 帧、1080P 规格内容
* 凭借对清晰度的深度优化，画质质感大幅跃升
* 写实风格逼近真实场景，2D 动画画风精准保持
* 首尾帧转场更加丝滑
* 适用于影视、广告、动漫短剧等高要求创作场景

📺 [**Vidu 2**](https://docs.bigmodel.cn/cn/guide/models/video-generation/vidu2)

* 平衡速度、质量与成本
* 主攻图生视频、首尾帧功能
* 支持 4 秒时长下 720P分辨率输出
* 画面稳定可控适配电商等场景
* 首尾帧语义理解与多参考图一致性增强
* 是泛娱乐、互联网、动漫短剧、广告量产的高效工具

**2025-04-23**

新增高识别精度、强抗噪能力的语音模型

💬 [**语音模型 GLM-ASR**](https://docs.bigmodel.cn/cn/guide/models/sound-and-video/glm-asr)

* 能够基于上下文理解将音频转录为符合语言习惯的文本
* 显著提升输出结果的流畅性和可读性
* 在噪音环境中较当前模型有明显较好的表现
* 不会被非语言类噪声干扰
* 支持中文、英语以及各地方方言（东北官话、胶辽官话、北京官话、冀鲁官话、中原官话、江淮官话、兰银官话和西南官话）
* 上新限时免费中～

**2025-04-14**

一次新增 2 个基座模型、3 个推理模型

🤖 **基座模型**

[**GLM-4-Air-250414（高性价比版）**](https://docs.bigmodel.cn/cn/guide/models/text/glm-4)

* 在工程代码、Artifacts 生成、函数调用、搜索问答及报告撰写等任务上均表现出色
* 性能比肩 GPT-4o、DeepSeek-V3-0324 等大尺寸模型水平

[**GLM-4-Flash-250414（免费版）**](https://docs.bigmodel.cn/cn/guide/models/free/glm-4-flash-250414)

* 免费使用
* 在通用任务上依然表现出色
* 适合轻量化任务

🧠 **推理模型**

[**GLM-Z1-AirX（极速版）**](https://docs.bigmodel.cn/cn/guide/models/text/glm-z1)

* 性能优异的推理模型
* 速度最快可达 200 tokens/秒（比常规快 8 倍）

[**GLM-Z1-Air（高性价比版）**](https://docs.bigmodel.cn/cn/guide/models/text/glm-z1)

* 价格仅为 DeepSeek-R1 的 1/30
* 适合高频调用场景

[**GLM-Z1-Flash（免费版）**](https://docs.bigmodel.cn/cn/guide/models/free/glm-z1-flash)

* 免费使用
* 进一步降低模型使用门槛

**2025-04-14**

一站式 AI 搜索工具全家桶更新升级

全系列 [AI 搜索工具](https://docs.bigmodel.cn/cn/guide/tools/web-search.md)升级上线，覆盖 基础检索（Web Search API）、问答增强（Web Search in Chat）、搜索智能体（Search Agent） 三大服务。新增支持 bing、搜狗、夸克、Jina.ai 等主流搜索引擎，灵活切换。优化了意图识别和结果搜索的准确度。[上新限时特惠](https://www.bigmodel.cn/pricing)

* **Web Search API：** 支持直接获取结构化搜索结果（标题/摘要/链接等），提供多搜索引擎支持（智谱自研/bing/搜狗/夸克/Jina AI）。
* **Chat Search：** 将 Web Search API 的搜索结果融入大模型，生成智能回答，并标注网页结果来源。
* **Search Agent：** 根据用户的 query，分析搜索意图，进行多个 query 拆解，将搜索结果融入大模型，提供全面、有深度的回答。


This documentation is built and hosted on [Mintlify](https://mintlify.com), a developer documentation platform.