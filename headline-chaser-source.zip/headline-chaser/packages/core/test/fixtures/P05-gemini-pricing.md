> ## AI Agent Context
> Get the complete documentation index at: https://aistudio.google.com/llms.txt
> Use this file to discover all available pages.
> For the full documentation in a single file, fetch: https://aistudio.google.com/llms-full.txt

# Gemini Developer API pricing

Start building free of charge with generous limits, then scale up with prepaid
and pay-as-you-go pricing for your production-ready applications.

{% card-grid %}
  {% card title="Free" %}
  For developers and small projects getting started with the Gemini API.

  {% hr /%}

  {% section class="checkmark-icon-list" %}
  * {% icon name="check_circle" /%} Limited access to certain models
  * {% icon name="check_circle" /%} Free input & output tokens
  * {% icon name="check_circle" /%} Google AI Studio access
  * {% icon name="check_circle" /%} Content used to improve our products{% sup %}[*](/docs/terms){% /sup %}

  {% /section %}

  {% section class="center-content align-bottom" %}
  {% button href="https://aistudio.google.com" %}
  Get started for Free

  {% /button %}

  {% /section %}

  {% /card %}

  {% card title="Paid" %}
  For production applications that require higher volumes and advanced features.

  {% hr /%}

  {% section class="checkmark-icon-list" %}
  * {% icon name="check_circle" /%} Higher rate limits for production deployments
  * {% icon name="check_circle" /%} Access to Context caching
  * {% icon name="check_circle" /%} Batch API (50% cost reduction)
  * {% icon name="check_circle" /%} Access to Google's most advanced models
  * {% icon name="check_circle" /%} Content **not** used to improve our products{% sup %}[*](/docs/terms){% /sup %}

  {% /section %}

  {% section class="center-content align-bottom" %}
  {% button href="https://aistudio.google.com/api-keys" %}
  Upgrade to Paid

  {% /button %}

  {% /section %}

  {% /card %}

  {% card title="Enterprise" %}
  For enterprise deployments, powered by
    [Gemini Enterprise Agent Platform](https://cloud.google.com/gemini-enterprise-agent-platform).

  {% hr /%}

  {% section class="checkmark-icon-list" %}
  * {% icon name="check_circle" /%} All features in Paid, plus optional access to:
  * {% icon name="check_circle" /%} Dedicated support channels
  * {% icon name="check_circle" /%} Advanced security & compliance
  * {% icon name="check_circle" /%} Provisioned throughput
  * {% icon name="check_circle" /%} Volume-based discounts (based on usage)
  * {% icon name="check_circle" /%} ML ops, model garden and more

  {% /section %}

  {% section class="center-content align-bottom" %}
  {% button href="https://cloud.google.com/contact" %}
  Contact Sales

  {% /button %}

  {% /section %}

  {% /card %}

{% /card-grid %}

## Gemini 4 Argon  {% id="gemini-4-argon" %}

{% two-column-layout %}
  {% left-column class="center-vertically" %}
  *[`gemini-4-argon`](/docs/models/gemini-4-argon)*

  {% /left-column %}

  {% right-column class="center-vertically right-align" %}
  {% button href="https://aistudio.google.com/prompts/new_chat?model=gemini-4-argon" variant="ais" %}
  Try it in Google AI Studio

  {% /button %}

  {% /right-column %}

{% /two-column-layout %}

{% hr /%}

Our flagship reasoning model, built for complex software engineering, deep
mathematical and scientific problem solving, autonomous multi-step agents, and
long-decode generation up to 1M tokens.

{% callout type="note" %}
  Gemini 4 Argon is not available on the Free tier. Every token the model processes is counted and billed, including thinking tokens and internal tool system instructions and function declarations when using grounding.

{% /callout %}

{% tabs %}
  {% tab title="Standard" %}
  {% table %}
  * Feature
  * Free Tier
  * Paid Tier, per 1M tokens in USD

  ---

  * Input price
  * Not available
  * $2.00 through November 30, 2026.   
  $4.00 starting December 1, 2026.

  ---

  * Output price (including thinking tokens)
  * Not available
  * $10.00 through November 30, 2026.   
  $20.00 starting December 1, 2026.

  ---

  * Context caching price
  * Not available
  * $0.10 through November 30, 2026.   
  $0.20 starting December 1, 2026.   
  Implicit caching only (explicit caching is not supported).

  ---

  * Grounding with Google Search{% sup %}*{% /sup %}
  * Not available
  * 5,000 free search requests per month (shared across all Gemini 3 and newer models),
  then $14 per 1,000 requests (subject to a [daily cap](/docs/pricing#pricing-for-tools) of 1,500 requests per day).

  ---

  * Grounding with Google Maps
  * Not available
  * 5,000 requests per month (free, shared across all Gemini 3 and newer models), then $14 / 1,000
  search queries.

  ---

  * Used to improve our products
  * Not available
  * [No](/docs/terms)
  {% /table %}

  {% sup %}*{% /sup %} A customer-submitted request to Gemini may result in one or
    more queries to Google Search. You will be charged for each individual search
    query performed.
    

  {% /tab %}

  {% tab title="Batch" %}
  {% table %}
  * Feature
  * Free Tier
  * Paid Tier, per 1M tokens in USD

  ---

  * Input price
  * Not available
  * $1.00 through November 30, 2026.   
  $2.00 starting December 1, 2026.

  ---

  * Output price (including thinking tokens)
  * Not available
  * $5.00 through November 30, 2026.   
  $10.00 starting December 1, 2026.

  ---

  * Context caching price
  * Not available
  * $0.05 through November 30, 2026.   
  $0.10 starting December 1, 2026.   
  Implicit caching only (explicit caching is not supported).

  ---

  * Used to improve our products
  * Not available
  * [No](/docs/terms)
  {% /table %}

  {% sup %}*{% /sup %} A customer-submitted request to Gemini may result in one or
    more queries to Google Search. You will be charged for each individual search
    query performed.
    

  {% /tab %}

  {% tab title="Flex" %}
  {% table %}
  * Feature
  * Free Tier
  * Paid Tier, per 1M tokens in USD

  ---

  * Input price
  * Not available
  * $1.00 through November 30, 2026.   
  $2.00 starting December 1, 2026.

  ---

  * Output price (including thinking tokens)
  * Not available
  * $5.00 through November 30, 2026.   
  $10.00 starting December 1, 2026.

  ---

  * Context caching price
  * Not available
  * $0.05 through November 30, 2026.   
  $0.10 starting December 1, 2026.   
  Implicit caching only (explicit caching is not supported).

  ---

  * Used to improve our products
  * Not available
  * [No](/docs/terms)
  {% /table %}

  {% sup %}*{% /sup %} A customer-submitted request to Gemini may result in one or
    more queries to Google Search. You will be charged for each individual search
    query performed.
    

  {% /tab %}

  {% tab title="Priority" %}
  {% table %}
  * Feature
  * Free Tier
  * Paid Tier, per 1M tokens in USD

  ---

  * Input price
  * Not available
  * $3.60 through November 30, 2026.   
  $7.20 starting December 1, 2026.

  ---

  * Output price (including thinking tokens)
  * Not available
  * $18.00 through November 30, 2026.   
  $36.00 starting December 1, 2026.

  ---

  * Context caching price
  * Not available
  * $0.18 through November 30, 2026.   
  $0.36 starting December 1, 2026.   
  Implicit caching only (explicit caching is not supported).

  ---

  * Grounding with Google Search{% sup %}*{% /sup %}
  * Not available
  * 5,000 free search requests per month (shared across all Gemini 3 and newer models),
  then $14 per 1,000 requests (subject to a [daily cap](/docs/pricing#pricing-for-tools) of 1,500 requests per day).

  ---

  * Grounding with Google Maps
  * Not available
  * 5,000 requests per month (free, shared across all Gemini 3 and newer models), then $14 / 1,000
  search queries.

  ---

  * Used to improve our products
  * Not available
  * [No](/docs/terms)
  {% /table %}

  {% sup %}*{% /sup %} A customer-submitted request to Gemini may result in one or
    more queries to Google Search. You will be charged for each individual search
    query performed.
    

  {% /tab %}

  {% tab title="Contributor" %}
  {% callout type="note" %}
  The Gemini API Contributor Tier is offered as a private preview on an
      invite-only basis. Speed and reliability are equivalent to
      [Standard Tier inference](/docs/optimization). Eligible users will be invited by
      email and see a callout in AI Studio.

  {% /callout %}

  {% table %}
  * Feature
  * Free Tier
  * Paid Tier, per 1M tokens in USD{% sup %}*{% /sup %}

  ---

  * Input price
  * Not available
  * $1.00

  ---

  * Output price (including thinking tokens)
  * Not available
  * $5.00

  ---

  * Context caching price
  * Not available
  * $0.05   
  Implicit caching only (explicit caching is not supported).

  ---

  * Used to improve our products
  * Not available
  * [Yes](/docs/logs-policy#contributor-tier)
  {% /table %}

  {% sup %}*{% /sup %} Discounts and model availability are subject to change.
    

  {% /tab %}

{% /tabs %}

## Gemini 3.8 Flash  {% id="gemini-3.8-flash" %}

{% two-column-layout %}
  {% left-column class="center-vertically" %}
  *[`gemini-3.8-flash`](/docs/models/gemini-3.8-flash)*

  {% /left-column %}

  {% right-column class="center-vertically right-align" %}
  {% button href="https://aistudio.google.com/prompts/new_chat?model=gemini-3.8-flash" variant="ais" %}
  Try it in Google AI Studio

  {% /button %}

  {% /right-column %}

{% /two-column-layout %}

{% hr /%}

Our most intelligent Flash model, engineered for long-horizon software
engineering, autonomous agents, and complex enterprise workflows.

{% tabs %}
  {% tab title="Standard" %}
  {% table %}
  * Feature
  * Free Tier
  * Paid Tier, per 1M tokens in USD

  ---

  * Input price
  * Free of charge
  * $0.75 through December 31, 2026.   
  $1.50 starting January 1, 2027.

  ---

  * Output price (including thinking tokens)
  * Free of charge
  * $3.75 through December 31, 2026.   
  $7.50 starting January 1, 2027.

  ---

  * Context caching price
  * Free of charge
  * $0.075 through December 31, 2026.   
  $0.15 starting January 1, 2027.   
  $0.50 / 1,000,000 tokens per hour (storage price) through December 31, 2026.   
  $1.00 / 1,000,000 tokens per hour (storage price) starting January 1, 2027.

  ---

  * Grounding with Google Search
  * Not available
  * 5,000 free search requests per month (shared across all Gemini 3 and newer models),
  then $14 per 1,000 requests (subject to a [daily cap](/docs/pricing#pricing-for-tools) of 1,500 requests per day).

  ---

  * Grounding with Google Maps
  * Not available
  * 5,000 requests per month (free, shared across all Gemini 3 and newer models), then $14 / 1,000
  search queries.

  ---

  * Used to improve our products
  * [Yes](/docs/terms)
  * [No](/docs/terms)
  {% /table %}

  {% /tab %}

  {% tab title="Batch" %}
  {% table %}
  * Feature
  * Free Tier
  * Paid Tier, per 1M tokens in USD

  ---

  * Input price
  * Not available
  * $0.375 through December 31, 2026.   
  $0.75 starting January 1, 2027.

  ---

  * Output price (including thinking tokens)
  * Not available
  * $1.875 through December 31, 2026.   
  $3.75 starting January 1, 2027.

  ---

  * Context caching price
  * Not available
  * $0.0375 through December 31, 2026.   
  $0.075 starting January 1, 2027.   
  $0.50 / 1,000,000 tokens per hour (storage price) through December 31, 2026.   
  $1.00 / 1,000,000 tokens per hour (storage price) starting January 1, 2027.

  ---

  * Used to improve our products
  * [Yes](/docs/terms)
  * [No](/docs/terms)
  {% /table %}

  {% /tab %}

  {% tab title="Flex" %}
  {% table %}
  * Feature
  * Free Tier
  * Paid Tier, per 1M tokens in USD

  ---

  * Input price
  * Not available
  * $0.375 through December 31, 2026.   
  $0.75 starting January 1, 2027.

  ---

  * Output price (including thinking tokens)
  * Not available
  * $1.875 through December 31, 2026.   
  $3.75 starting January 1, 2027.

  ---

  * Context caching price
  * Not available
  * $0.0375 through December 31, 2026.   
  $0.075 starting January 1, 2027.   
  $0.50 / 1,000,000 tokens per hour (storage price) through December 31, 2026.   
  $1.00 / 1,000,000 tokens per hour (storage price) starting January 1, 2027.

  ---

  * Used to improve our products
  * [Yes](/docs/terms)
  * [No](/docs/terms)
  {% /table %}

  {% /tab %}

  {% tab title="Priority" %}
  {% table %}
  * Feature
  * Free Tier
  * Paid Tier, per 1M tokens in USD

  ---

  * Input price
  * Free of charge
  * $1.35 through December 31, 2026.   
  $2.70 starting January 1, 2027.

  ---

  * Output price (including thinking tokens)
  * Free of charge
  * $6.75 through December 31, 2026.   
  $13.50 starting January 1, 2027.

  ---

  * Context caching price
  * Free of charge
  * $0.135 through December 31, 2026.   
  $0.27 starting January 1, 2027.   
  $0.50 / 1,000,000 tokens per hour (storage price) through December 31, 2026.   
  $1.00 / 1,000,000 tokens per hour (storage price) starting January 1, 2027.

  ---

  * Grounding with Google Search{% sup %}*{% /sup %}
  * Not available{% sup %}**{% /sup %}
  * 5,000 free search requests per month (shared across all Gemini 3 and newer models),
  then $14 per 1,000 requests (subject to a [daily cap](/docs/pricing#pricing-for-tools) of 1,500 requests per day).

  ---

  * Grounding with Google Maps
  * Not available{% sup %}**{% /sup %}
  * 5,000 requests per month (free, shared across all Gemini 3 and newer models), then $14 / 1,000
  search queries.

  ---

  * Used to improve our products
  * [Yes](/docs/terms)
  * [No](/docs/terms)
  {% /table %}

  {% /tab %}

  {% tab title="Contributor" %}
  {% callout type="note" %}
  The Gemini API Contributor Tier is offered as a private preview on an
      invite-only basis. Speed and reliability are equivalent to
      [Standard Tier inference](/docs/optimization). Eligible users will be invited by
      email and see a callout in AI Studio.

  {% /callout %}

  {% table %}
  * Feature
  * Free Tier
  * Paid Tier, per 1M tokens in USD{% sup %}*{% /sup %}

  ---

  * Input price
  * Free of charge
  * $0.375

  ---

  * Output price (including thinking tokens)
  * Free of charge
  * $1.875

  ---

  * Context caching price
  * Free of charge
  * $0.0375   
  $0.50 / 1,000,000 tokens per hour (storage price)

  ---

  * Used to improve our products
  * [Yes](/docs/terms)
  * [Yes](/docs/logs-policy#contributor-tier)
  {% /table %}

  {% sup %}*{% /sup %} Discounts and model availability are subject to change.
    

  {% /tab %}

{% /tabs %}

## Gemini 3.6 Flash  {% id="gemini-3.6-flash" %}

{% two-column-layout %}
  {% left-column %}
  *[`gemini-3.6-flash`](/docs/models/gemini-3.6-flash)*

  {% /left-column %}

  {% right-column class="center-vertically right-align" %}
  {% button href="https://aistudio.google.com/prompts/new_chat?model=gemini-3.6-flash" variant="ais" %}
  Try it in Google AI Studio

  {% /button %}

  {% /right-column %}

{% /two-column-layout %}

{% hr /%}

Our previous generation Flash model, balancing speed and multimodal capabilities
across general agentic and everyday tasks.

{% tabs %}
  {% tab title="Standard" %}
  {% table %}
  * Feature
  * Free Tier
  * Paid Tier, per 1M tokens in USD

  ---

  * Input price
  * Free of charge
  * $0.75 through December 31, 2026.   
  $1.50 starting January 1, 2027.

  ---

  * Output price (including thinking tokens)
  * Free of charge
  * $3.75 through December 31, 2026.   
  $7.50 starting January 1, 2027.

  ---

  * Context caching price
  * Free of charge
  * $0.075 through December 31, 2026.   
  $0.15 starting January 1, 2027.   
  $0.50 / 1,000,000 tokens per hour (storage price) through December 31, 2026.   
  $1.00 / 1,000,000 tokens per hour (storage price) starting January 1, 2027.

  ---

  * Grounding with Google Search{% sup %}*{% /sup %}
  * Not available{% sup %}**{% /sup %}
  * 5,000 free search requests per month (shared across all Gemini 3 and newer models),
  then $14 per 1,000 requests (subject to a [daily cap](/docs/pricing#pricing-for-tools) of 1,500 requests per day).

  ---

  * Grounding with Google Maps
  * Not available{% sup %}**{% /sup %}
  * 5,000 requests per month (free, shared across all Gemini 3 and newer models), then $14 / 1,000
  search queries.

  ---

  * Used to improve our products
  * [Yes](/docs/terms)
  * [No](/docs/terms)
  {% /table %}

  {% /tab %}

  {% tab title="Batch" %}
  {% table %}
  * Feature
  * Free Tier
  * Paid Tier, per 1M tokens in USD

  ---

  * Input price
  * Not available
  * $0.375 through December 31, 2026.   
  $0.75 starting January 1, 2027.

  ---

  * Output price (including thinking tokens)
  * Not available
  * $1.875 through December 31, 2026.   
  $3.75 starting January 1, 2027.

  ---

  * Context caching price
  * Not available
  * $0.0375 through December 31, 2026.   
  $0.075 starting January 1, 2027.   
  $0.50 / 1,000,000 tokens per hour (storage price) through December 31, 2026.   
  $1.00 / 1,000,000 tokens per hour (storage price) starting January 1, 2027.

  ---

  * Grounding with Google Search{% sup %}*{% /sup %}
  * Not available{% sup %}**{% /sup %}
  * 5,000 free search requests per month (shared across all Gemini 3 and newer models),
  then $14 per 1,000 requests (subject to a [daily cap](/docs/pricing#pricing-for-tools) of 1,500 requests per day).

  ---

  * Grounding with Google Maps
  * Not available{% sup %}**{% /sup %}
  * 5,000 requests per month (free, shared across all Gemini 3 and newer models), then $14 / 1,000
  search queries.

  ---

  * Used to improve our products
  * [Yes](/docs/terms)
  * [No](/docs/terms)
  {% /table %}

  {% /tab %}

  {% tab title="Flex" %}
  {% table %}
  * Feature
  * Free Tier
  * Paid Tier, per 1M tokens in USD

  ---

  * Input price
  * Not available
  * $0.375 through December 31, 2026.   
  $0.75 starting January 1, 2027.

  ---

  * Output price (including thinking tokens)
  * Not available
  * $1.875 through December 31, 2026.   
  $3.75 starting January 1, 2027.

  ---

  * Context caching price
  * Not available
  * $0.0375 through December 31, 2026.   
  $0.075 starting January 1, 2027.   
  $0.50 / 1,000,000 tokens per hour (storage price) through December 31, 2026.   
  $1.00 / 1,000,000 tokens per hour (storage price) starting January 1, 2027.

  ---

  * Grounding with Google Search{% sup %}*{% /sup %}
  * Not available{% sup %}**{% /sup %}
  * 5,000 free search requests per month (shared across all Gemini 3 and newer models),
  then $14 per 1,000 requests (subject to a [daily cap](/docs/pricing#pricing-for-tools) of 1,500 requests per day).

  ---

  * Grounding with Google Maps
  * Not available{% sup %}**{% /sup %}
  * 5,000 requests per month (free, shared across all Gemini 3 and newer models), then $14 / 1,000
  search queries.

  ---

  * Used to improve our products
  * [Yes](/docs/terms)
  * [No](/docs/terms)
  {% /table %}

  {% /tab %}

  {% tab title="Priority" %}
  {% table %}
  * Feature
  * Free Tier
  * Paid Tier, per 1M tokens in USD

  ---

  * Input price
  * Free of charge
  * $1.35 through December 31, 2026.   
  $2.70 starting January 1, 2027.

  ---

  * Output price (including thinking tokens)
  * Free of charge
  * $6.75 through December 31, 2026.   
  $13.50 starting January 1, 2027.

  ---

  * Context caching price
  * Free of charge
  * $0.135 through December 31, 2026.   
  $0.27 starting January 1, 2027.   
  $0.50 / 1,000,000 tokens per hour (storage price) through December 31, 2026.   
  $1.00 / 1,000,000 tokens per hour (storage price) starting January 1, 2027.

  ---

  * Grounding with Google Search{% sup %}*{% /sup %}
  * Not available{% sup %}**{% /sup %}
  * 5,000 free search requests per month (shared across all Gemini 3 and newer models),
  then $14 per 1,000 requests (subject to a [daily cap](/docs/pricing#pricing-for-tools) of 1,500 requests per day).

  ---

  * Grounding with Google Maps
  * Not available{% sup %}**{% /sup %}
  * 5,000 requests per month (free, shared across all Gemini 3 and newer models), then $14 / 1,000
  search queries.

  ---

  * Used to improve our products
  * [Yes](/docs/terms)
  * [No](/docs/terms)
  {% /table %}

  {% /tab %}

{% /tabs %}

{% sup %}*{% /sup %} A customer-submitted request to Gemini may result in one or
more queries to Google Search. You will be charged for each individual search
query performed.

{% sup %}**{% /sup %} Can be tested in Google AI Studio.

## Gemini 3.5 Transcribe Live  {% id="gemini-3.5-transcribe-live" %}

{% two-column-layout %}
  {% left-column %}
  *[`gemini-3.5-transcribe-live`](/docs/models/gemini-3.5-transcribe)*

  {% /left-column %}

  {% right-column class="center-vertically right-align" %}
  {% button href="https://aistudio.google.com?model=gemini-3.5-transcribe-live" variant="ais" %}
  Try it in Google AI Studio

  {% /button %}

  {% /right-column %}

{% /two-column-layout %}

{% hr /%}

Our low-latency, real-time speech-to-text model for bidirectional streaming
audio transcription over WebSockets.

{% tabs %}
  {% tab title="Standard" %}
  {% table %}
  * Feature
  * Free Tier
  * Paid Tier, per 1M tokens in USD

  ---

  * Input price
  * Free of charge
  * $3.50 or $0.005/min{% sup %}*{% /sup %} (audio)

  ---

  * Output price (including thinking tokens)
  * Free of charge
  * $21.00 or $0.004/min{% sup %}*{% /sup %} (text)

  ---

  * Grounding with Google Search
  * Not Supported
  * 

  ---

  * Used to improve our products
  * [Yes](/docs/terms)
  * [No](/docs/terms)
  {% /table %}

  {% /tab %}

{% /tabs %}

{% sup %}*{% /sup %} Estimated pricing is based on 25 audio tokens per second
for input and 175 text tokens per minute for output, for an effective blended
rate of ~$0.009 per min for Live Transcribe.

## Gemini 3.5 Transcribe  {% id="gemini-3.5-transcribe" %}

{% two-column-layout %}
  {% left-column %}
  *[`gemini-3.5-transcribe`](/docs/models/gemini-3.5-transcribe)*

  {% /left-column %}

  {% right-column class="center-vertically right-align" %}
  {% button href="https://aistudio.google.com?model=gemini-3.5-transcribe" variant="ais" %}
  Try it in Google AI Studio

  {% /button %}

  {% /right-column %}

{% /two-column-layout %}

{% hr /%}

Our speech-to-text model with automatic language detection, speaker diarization,
word-level timestamps, and custom vocabulary biasing.

{% tabs %}
  {% tab title="Standard" %}
  {% table %}
  * Feature
  * Free Tier
  * Paid Tier, per 1M tokens in USD

  ---

  * Input price
  * Free of charge
  * $2.00 or $0.003/min{% sup %}*{% /sup %} (audio)

  ---

  * Output price (including thinking tokens)
  * Free of charge
  * $12.00 or $0.002/min{% sup %}*{% /sup %} (text)

  ---

  * Grounding with Google Search
  * Not Supported
  * 

  ---

  * Used to improve our products
  * [Yes](/docs/terms)
  * [No](/docs/terms)
  {% /table %}

  {% /tab %}

{% /tabs %}

{% sup %}*{% /sup %} Estimated pricing is based on 25 audio tokens per second
for input and 175 text tokens per minute for output, for an effective blended
rate of ~$0.005 per min for Transcribe.

## Gemini 3.5 Flash-Lite  {% id="gemini-3.5-flash-lite" %}

{% two-column-layout %}
  {% left-column %}
  *[`gemini-3.5-flash-lite`](/docs/models/gemini-3.5-flash-lite)*

  {% /left-column %}

  {% right-column class="center-vertically right-align" %}
  {% button href="https://aistudio.google.com/prompts/new_chat?model=gemini-3.5-flash-lite" variant="ais" %}
  Try it in Google AI Studio

  {% /button %}

  {% /right-column %}

{% /two-column-layout %}

{% hr /%}

A cost-efficient model, optimized for high-volume agentic tasks, translation,
and simple data processing.

{% tabs %}
  {% tab title="Standard" %}
  {% table %}
  * Feature
  * Free Tier
  * Paid Tier, per 1M tokens in USD

  ---

  * Input price
  * Free of charge
  * $0.30 (text / image / video / audio)

  ---

  * Output price (including thinking tokens)
  * Free of charge
  * $2.50

  ---

  * Context caching price
  * Not available
  * $0.03    
  $1.00 / 1,000,000 tokens per hour (storage price)

  ---

  * Grounding with Google Search{% sup %}*{% /sup %}
  * Not available{% sup %}**{% /sup %}
  * 5,000 free search requests per month (shared across all Gemini 3 and newer models),
  then $14 per 1,000 requests (subject to a [daily cap](/docs/pricing#pricing-for-tools) of 1,500 requests per day).

  ---

  * Grounding with Google Maps
  * Not available{% sup %}**{% /sup %}
  * 5,000 requests per month (free, shared across all Gemini 3 and newer models), then $14 / 1,000
  search queries.

  ---

  * Used to improve our products
  * [Yes](/docs/terms)
  * [No](/docs/terms)
  {% /table %}

  {% sup %}*{% /sup %} A customer-submitted request to Gemini may result in one or
    more queries to Google Search. You will be charged for each individual search
    query performed.

  {% sup %}**{% /sup %} Can be tested in Google AI Studio.
    

  {% /tab %}

  {% tab title="Batch" %}
  {% table %}
  * Feature
  * Free Tier
  * Paid Tier, per 1M tokens in USD

  ---

  * Input price
  * Free of charge
  * $0.15 (text / image / video / audio)

  ---

  * Output price (including thinking tokens)
  * Free of charge
  * $1.25

  ---

  * Context caching price
  * Not available
  * $0.015    
  $1.00 / 1,000,000 tokens per hour (storage price)

  ---

  * Grounding with Google Search{% sup %}*{% /sup %}
  * Not available{% sup %}**{% /sup %}
  * 5,000 free search requests per month (shared across all Gemini 3 and newer models),
  then $14 per 1,000 requests (subject to a [daily cap](/docs/pricing#pricing-for-tools) of 1,500 requests per day).

  ---

  * Grounding with Google Maps
  * Not available{% sup %}**{% /sup %}
  * 5,000 requests per month (free, shared across all Gemini 3 and newer models), then $14 / 1,000
  search queries.

  ---

  * Used to improve our products
  * [Yes](/docs/terms)
  * [No](/docs/terms)
  {% /table %}

  {% sup %}*{% /sup %} A customer-submitted request to Gemini may result in one or
    more queries to Google Search. You will be charged for each individual search
    query performed.

  {% sup %}**{% /sup %} Can be tested in Google AI Studio.
    

  {% /tab %}

  {% tab title="Flex" %}
  {% table %}
  * Feature
  * Free Tier
  * Paid Tier, per 1M tokens in USD

  ---

  * Input price
  * Not available
  * $0.15 (text / image / video / audio)

  ---

  * Output price (including thinking tokens)
  * Not available
  * $1.25

  ---

  * Context caching price
  * Not available
  * $0.02    
  $1.00 / 1,000,000 tokens per hour (storage price)

  ---

  * Grounding with Google Search{% sup %}*{% /sup %}
  * Not available{% sup %}**{% /sup %}
  * 5,000 free search requests per month (shared across all Gemini 3 and newer models),
  then $14 per 1,000 requests (subject to a [daily cap](/docs/pricing#pricing-for-tools) of 1,500 requests per day).

  ---

  * Grounding with Google Maps
  * Not available{% sup %}**{% /sup %}
  * 5,000 requests per month (free, shared across all Gemini 3 and newer models), then $14 / 1,000
  search queries.

  ---

  * Used to improve our products
  * [Yes](/docs/terms)
  * [No](/docs/terms)
  {% /table %}

  {% sup %}*{% /sup %} A customer-submitted request to Gemini may result in one or
    more queries to Google Search. You will be charged for each individual search
    query performed.

  {% sup %}**{% /sup %} Can be tested in Google AI Studio.
    

  {% /tab %}

  {% tab title="Priority" %}
  {% table %}
  * Feature
  * Free Tier
  * Paid Tier, per 1M tokens in USD

  ---

  * Input price
  * Free of charge
  * $0.54 (text / image / video / audio)

  ---

  * Output price (including thinking tokens)
  * Free of charge
  * $4.50

  ---

  * Context caching price
  * Not available
  * $0.05    
  $1.00 / 1,000,000 tokens per hour (storage price)

  ---

  * Grounding with Google Search{% sup %}*{% /sup %}
  * Not available{% sup %}**{% /sup %}
  * 5,000 free search requests per month (shared across all Gemini 3 and newer models),
  then $14 per 1,000 requests (subject to a [daily cap](/docs/pricing#pricing-for-tools) of 1,500 requests per day).

  ---

  * Grounding with Google Maps
  * Not available{% sup %}**{% /sup %}
  * 5,000 requests per month (free, shared across all Gemini 3 and newer models), then $14 / 1,000
  search queries.

  ---

  * Used to improve our products
  * [Yes](/docs/terms)
  * [No](/docs/terms)
  {% /table %}

  {% sup %}*{% /sup %} A customer-submitted request to Gemini may result in one or
    more queries to Google Search. You will be charged for each individual search
    query performed.

  {% sup %}**{% /sup %} Can be tested in Google AI Studio.
    

  {% /tab %}

  {% tab title="Contributor" %}
  {% callout type="note" %}
  The Gemini API Contributor Tier is offered as a private preview on an
      invite-only basis. Speed and reliability are equivalent to
      [Standard Tier inference](/docs/optimization). Eligible users will be invited by
      email and see a callout in AI Studio.

  {% /callout %}

  {% table %}
  * Feature
  * Free Tier
  * Paid Tier, per 1M tokens in USD{% sup %}*{% /sup %}

  ---

  * Input price
  * Free of charge
  * $0.15 (text / image / video / audio)

  ---

  * Output price (including thinking tokens)
  * Free of charge
  * $1.25

  ---

  * Context caching price
  * Not available
  * $0.015    
  $1.00 / 1,000,000 tokens per hour (storage price)

  ---

  * Used to improve our products
  * [Yes](/docs/terms)
  * [Yes](/docs/logs-policy#contributor-tier)
  {% /table %}

  {% sup %}*{% /sup %} Discounts and model availability are subject to change.
    

  {% /tab %}

{% /tabs %}

## Gemini Omni 1.2 Flash  {% id="gemini-omni-1.2-flash" %}

{% two-column-layout %}
  {% left-column class="center-vertically" %}
  *[`gemini-omni-1.2-flash`](/docs/models/gemini-omni-flash)*

  {% /left-column %}

  {% right-column class="center-vertically right-align" %}
  {% button href="https://aistudio.google.com/prompts/new_chat?model=gemini-omni-1.2-flash" variant="ais" %}
  Try it in Google AI Studio

  {% /button %}

  {% /right-column %}

{% /two-column-layout %}

{% hr /%}

Our next-generation video generation and editing model supporting up to 15
seconds of video generation and editing with native audio, now generally
available to developers on the paid tier of the Gemini API.

{% tabs %}
  {% tab title="Standard" %}
  {% table %}
  * Feature
  * Free Tier
  * Paid Tier, per 1M tokens in USD

  ---

  * Input price
  * Not available
  * $1.50 (text / image / video)

  ---

  * Output price (including thinking tokens)
  * Not available
  * $9.00 (text)    
  $12.00 (video){% sup %}*{% /sup %}

  ---

  * Used to improve our products
  * [Yes](/docs/terms)
  * [No](/docs/terms)
  {% /table %}

  {% /tab %}

{% /tabs %}

{% sup %}*{% /sup %} Billing is based on total output token consumption,
calculated at a rate of 5,792 tokens per second of 720p video. Under Standard
pricing ($12.00 per 1M tokens), this equates to an effective price of
approximately $0.07 per second (~$0.70 for a 10s clip, ~$1.04 for a 15s clip;
$0.023/s for 360p at 1,931 tokens/s; $0.104/s for 1080p with upsampling at 8,688
tokens/s; and $0.209/s for 4K with upsampling at 17,376 tokens/s).

## Gemini Omni 1.1 Flash  {% id="gemini-omni-1.1-flash" %}

{% two-column-layout %}
  {% left-column class="center-vertically" %}
  *[`gemini-omni-1.1-flash`](/docs/models/gemini-omni-flash#gemini-omni-1.1-flash)*

  {% /left-column %}

  {% right-column class="center-vertically right-align" %}
  {% button href="https://aistudio.google.com/prompts/new_chat?model=gemini-omni-1.2-flash" variant="ais" %}
  Try it in Google AI Studio

  {% /button %}

  {% /right-column %}

{% /two-column-layout %}

{% hr /%}

Previous generation video generation and editing model. Effective December 3,
2026, all API requests to `gemini-omni-1.1-flash` automatically route to
[`gemini-omni-1.2-flash`](/docs/models/gemini-omni-flash#gemini-omni-1.2-flash)
and are billed at `gemini-omni-1.2-flash` rates.

{% tabs %}
  {% tab title="Standard" %}
  {% table %}
  * Feature
  * Free Tier
  * Paid Tier, per 1M tokens in USD

  ---

  * Input price
  * Not available
  * $1.50 (text / image / video)

  ---

  * Output price (including thinking tokens)
  * Not available
  * $9.00 (text)    
  $17.50 (video){% sup %}*{% /sup %}

  ---

  * Used to improve our products
  * [Yes](/docs/terms)
  * [No](/docs/terms)
  {% /table %}

  {% /tab %}

{% /tabs %}

{% sup %}*{% /sup %} Billing is based on total output token consumption,
calculated at a rate of 5,792 tokens per second of 720p video. Under Standard
pricing, this equates to an effective price of approximately $0.10 per second.

## Gemini 3.8 Live, Gemini 3.8 Live Extended Thinking, and Gemini 3.1 Flash Live Preview  {% id="gemini-3.8-live" %}

{% two-column-layout %}
  

  {% left-column class="center-vertically" %}
  *[`gemini-3.8-live`](/docs/models/gemini-3.8-live),
    [`gemini-3.8-live-extended-thinking`](/docs/models/gemini-3.8-live-extended-thinking),
    [`gemini-3.1-flash-live-preview`](/docs/models/gemini-3.1-flash-live-preview)*

  {% /left-column %}

  

  {% right-column class="center-vertically right-align" %}
   {% button href="https://aistudio.google.com/live?model=gemini-3.8-live" variant="ais" %} Try it in Google AI Studio {% /button %}

  {% /right-column %}

  

{% /two-column-layout %}

{% hr /%}

Our low-latency, audio-to-audio models optimized for real-time dialogue with
acoustic nuance detection, numeric precision, and multimodal awareness.

{% table %}
  * Feature
  * Free Tier
  * Paid Tier, per 1M tokens in USD

  ---

  * Input price
  * Free of charge
  * $0.75 (text)    
    $3.00 or $0.005/min (audio)    
    $1.00 or $0.002/min (image/video)

  ---

  * Output price (including thinking tokens)
  * Free of charge
  * $4.50 (text)    
    $12.00 or $0.018/min (audio)

  ---

  * Grounding with Google Search{% sup %}*{% /sup %}
  * Supported
  * 5,000 free search requests per month (shared across all Gemini 3 and newer models),
    then $14 per 1,000 requests (subject to a [daily cap](/docs/pricing#pricing-for-tools) of 1,500 requests per day).

  ---

  * Used to improve our products
  * [Yes](/docs/terms)
  * [No](/docs/terms)
{% /table %}

{% sup %}*{% /sup %} A customer-submitted request to Gemini may result in one or
more queries to Google Search. You will be charged for each individual search
query performed.

## Gemini 3.5 Live Translate  {% id="gemini-3.5-live-translate-preview" %}

{% two-column-layout %}
  {% left-column class="center-vertically" %}
  *[`gemini-3.5-live-translate-preview`](/docs/models/gemini-3.5-live-translate-preview)*

  {% /left-column %}

  {% right-column class="center-vertically right-align" %}
  {% button href="https://aistudio.google.com/live?model=gemini-3.5-live-translate-preview" variant="ais" %}
  Try it in Google AI Studio

  {% /button %}

  {% /right-column %}

{% /two-column-layout %}

{% hr /%}

Our low-latency, real-time speech to speech translation model that supports 70+
languages.

{% tabs %}
  {% tab title="Standard" %}
  {% table %}
  * Feature
  * Free Tier
  * Paid Tier, per 1M tokens in USD

  ---

  * Input price
  * Free of charge
  * $3.50 or $0.0053/min{% sup %}*{% /sup %} (audio)

  ---

  * Output price (including thinking tokens)
  * Free of charge
  * $21.00 or $0.0315/min{% sup %}*{% /sup %} (audio)

  ---

  * Used to improve our products
  * [Yes](/docs/terms)
  * [No](/docs/terms)
  {% /table %}

  {% /tab %}

{% /tabs %}

{% sup %}*{% /sup %} Billing is based on total input and output audio token
consumption, calculated at a rate of 25 tokens per second of audio, equating to
an effective price of approximately $0.0368 per minute.

## Gemini 3.1 Flash-Lite  {% id="gemini-3.1-flash-lite" %}

{% two-column-layout %}
  {% left-column class="center-vertically" %}
  *[`gemini-3.1-flash-lite`](/docs/models/gemini-3.1-flash-lite)*

  {% /left-column %}

  {% right-column class="center-vertically right-align" %}
  {% button href="https://aistudio.google.com/prompts/new_chat?model=gemini-3.1-flash-lite" variant="ais" %}
  Try it in Google AI Studio

  {% /button %}

  {% /right-column %}

{% /two-column-layout %}

{% hr /%}

A cost-efficient model, optimized for high-volume agentic tasks, translation,
and simple data processing.

{% tabs %}
  {% tab title="Standard" %}
  {% table %}
  * Feature
  * Free Tier
  * Paid Tier, per 1M tokens in USD

  ---

  * Input price
  * Free of charge
  * $0.25 (text / image / video)    
  $0.50 (audio)

  ---

  * Output price (including thinking tokens)
  * Free of charge
  * $1.50

  ---

  * Context caching price
  * Not available
  * $0.025 (text / image / video)    
  $0.05 (audio)    
  $1.00 / 1,000,000 tokens per hour (storage price)

  ---

  * Grounding with Google Search{% sup %}*{% /sup %}
  * Not available{% sup %}**{% /sup %}
  * 5,000 free search requests per month (shared across all Gemini 3 and newer models),
  then $14 per 1,000 requests (subject to a [daily cap](/docs/pricing#pricing-for-tools) of 1,500 requests per day).

  ---

  * Grounding with Google Maps
  * Not available{% sup %}**{% /sup %}
  * 5,000 requests per month (free, shared across all Gemini 3 and newer models), then $14 / 1,000
  search queries.

  ---

  * Used to improve our products
  * [Yes](/docs/terms)
  * [No](/docs/terms)
  {% /table %}

  {% /tab %}

  {% tab title="Batch" %}
  {% table %}
  * Feature
  * Free Tier
  * Paid Tier, per 1M tokens in USD

  ---

  * Input price
  * Free of charge
  * $0.125 (text / image / video)    
  $0.25 (audio)

  ---

  * Output price (including thinking tokens)
  * Free of charge
  * $0.75

  ---

  * Context caching price
  * Not available
  * $0.0125 (text / image / video)    
  $0.025 (audio)    
  $0.50 / 1,000,000 tokens per hour (storage price)

  ---

  * Grounding with Google Search{% sup %}*{% /sup %}
  * Not available{% sup %}**{% /sup %}
  * 5,000 free search requests per month (shared across all Gemini 3 and newer models),
  then $14 per 1,000 requests (subject to a [daily cap](/docs/pricing#pricing-for-tools) of 1,500 requests per day).

  ---

  * Grounding with Google Maps
  * Not available{% sup %}**{% /sup %}
  * 5,000 requests per month (free, shared across all Gemini 3 and newer models), then $14 / 1,000
  search queries.

  ---

  * Used to improve our products
  * [Yes](/docs/terms)
  * [No](/docs/terms)
  {% /table %}

  {% /tab %}

  {% tab title="Flex" %}
  {% table %}
  * Feature
  * Free Tier
  * Paid Tier, per 1M tokens in USD

  ---

  * Input price
  * Free of charge
  * $0.125 (text / image / video)    
  $0.25 (audio)

  ---

  * Output price (including thinking tokens)
  * Free of charge
  * $0.75

  ---

  * Context caching price
  * Not available
  * $0.0125 (text / image / video)    
  $0.025 (audio)    
  $0.50 / 1,000,000 tokens per hour (storage price)

  ---

  * Grounding with Google Search{% sup %}*{% /sup %}
  * Not available{% sup %}**{% /sup %}
  * 5,000 free search requests per month (shared across all Gemini 3 and newer models),
  then $14 per 1,000 requests (subject to a [daily cap](/docs/pricing#pricing-for-tools) of 1,500 requests per day).

  ---

  * Grounding with Google Maps
  * Not available{% sup %}**{% /sup %}
  * 5,000 requests per month (free, shared across all Gemini 3 and newer models), then $14 / 1,000
  search queries.

  ---

  * Used to improve our products
  * [Yes](/docs/terms)
  * [No](/docs/terms)
  {% /table %}

  {% /tab %}

  {% tab title="Priority" %}
  {% table %}
  * Feature
  * Free Tier
  * Paid Tier, per 1M tokens in USD

  ---

  * Input price
  * Free of charge
  * $0.45 (text / image / video)    
  $0.90 (audio)

  ---

  * Output price (including thinking tokens)
  * Free of charge
  * $2.70

  ---

  * Context caching price
  * Not available
  * $0.045 (text / image / video)    
  $0.09 (audio)    
  $1.80 / 1,000,000 tokens per hour (storage price)

  ---

  * Grounding with Google Search{% sup %}*{% /sup %}
  * Not available{% sup %}**{% /sup %}
  * 5,000 free search requests per month (shared across all Gemini 3 and newer models),
  then $14 per 1,000 requests (subject to a [daily cap](/docs/pricing#pricing-for-tools) of 1,500 requests per day).

  ---

  * Grounding with Google Maps
  * Not available{% sup %}**{% /sup %}
  * 5,000 requests per month (free, shared across all Gemini 3 and newer models), then $14 / 1,000
  search queries.

  ---

  * Used to improve our products
  * [Yes](/docs/terms)
  * [No](/docs/terms)
  {% /table %}

  {% /tab %}

{% /tabs %}

{% sup %}*{% /sup %} A customer-submitted request to Gemini may result in one or
more queries to Google Search. You will be charged for each individual search
query performed.

{% sup %}**{% /sup %} Can be tested in Google AI Studio.

## Gemini 3.1 Pro Preview  {% id="gemini-3.1-pro-preview" %}

{% two-column-layout %}
  {% left-column class="center-vertically" %}
  *[`gemini-3.1-pro-preview`](/docs/models/gemini-3.1-pro-preview) and
    [`gemini-3.1-pro-preview-customtools`](/docs/models/gemini-3.1-pro-preview#gemini-31-pro-preview-customtools)*

  {% /left-column %}

  {% right-column class="center-vertically right-align" %}
  {% button href="https://aistudio.google.com/prompts/new_chat?model=gemini-3.1-pro-preview" variant="ais" %}
  Try it in Google AI Studio

  {% /button %}

  {% /right-column %}

{% /two-column-layout %}

{% hr /%}

Our 3rd generation Pro model, built for multimodal understanding, agentic
capabilities, and vibe-coding.

{% tabs %}
  {% tab title="Standard" %}
  {% table %}
  * Feature
  * Free Tier
  * Paid Tier, per 1M tokens in USD

  ---

  * Input price
  * Not available
  * $2.00, prompts <= 200k tokens    
  $4.00, prompts > 200k tokens

  ---

  * Output price (including thinking tokens)
  * Not available
  * $12.00, prompts <= 200k tokens    
  $18.00, prompts > 200k

  ---

  * Context caching price
  * Not available
  * $0.20, prompts <= 200k tokens    
  $0.40, prompts > 200k    
  $4.50 / 1,000,000 tokens per hour (storage price)

  ---

  * Grounding with Google Search{% sup %}*{% /sup %}
  * Not available{% sup %}**{% /sup %}
  * 5,000 free search requests per month (shared across all Gemini 3 and newer models),
  then $14 per 1,000 requests (subject to a [daily cap](/docs/pricing#pricing-for-tools) of 1,500 requests per day).

  ---

  * Grounding with Google Maps
  * Not available{% sup %}**{% /sup %}
  * 5,000 requests per month (free, shared across all Gemini 3 and newer models), then $14 / 1,000
  search queries.

  ---

  * Used to improve our products
  * Not available
  * [No](/docs/terms)
  {% /table %}

  {% sup %}*{% /sup %} A customer-submitted request to Gemini may result in one or
    more queries to Google Search. You will be charged for each individual search
    query performed.

  {% sup %}**{% /sup %} Can be tested in Google AI Studio.
    

  {% /tab %}

  {% tab title="Batch" %}
  {% table %}
  * Feature
  * Free Tier
  * Paid Tier, per 1M tokens in USD

  ---

  * Input price
  * Not available
  * $1.00, prompts <= 200k tokens    
  $2.00, prompts > 200k tokens

  ---

  * Output price (including thinking tokens)
  * Not available
  * $6.00, prompts <= 200k tokens    
  $9.00, prompts > 200k

  ---

  * Context caching price
  * Not available
  * *Same as Standard*    
  $0.20, prompts <= 200k tokens    
  $0.40, prompts > 200k    
  $4.50 / 1,000,000 tokens per hour (storage price)

  ---

  * Grounding with Google Search{% sup %}*{% /sup %}
  * Not available{% sup %}**{% /sup %}
  * 5,000 free search requests per month (shared across all Gemini 3 and newer models),
  then $14 per 1,000 requests (subject to a [daily cap](/docs/pricing#pricing-for-tools) of 1,500 requests per day).

  ---

  * Grounding with Google Maps
  * Not available{% sup %}**{% /sup %}
  * 5,000 requests per month (free, shared across all Gemini 3 and newer models), then $14 / 1,000
  search queries.

  ---

  * Used to improve our products
  * Not available
  * [No](/docs/terms)
  {% /table %}

  {% sup %}*{% /sup %} A customer-submitted request to Gemini may result in one or
    more queries to Google Search. You will be charged for each individual search
    query performed.

  {% sup %}**{% /sup %} Can be tested in Google AI Studio.
    

  {% /tab %}

  {% tab title="Flex" %}
  {% table %}
  * Feature
  * Free Tier
  * Paid Tier, per 1M tokens in USD

  ---

  * Input price
  * Not available
  * $1.00, prompts <= 200k tokens    
  $2.00, prompts > 200k tokens

  ---

  * Output price (including thinking tokens)
  * Not available
  * $6.00, prompts <= 200k tokens    
  $9.00, prompts > 200k

  ---

  * Context caching price
  * Not available
  * *Same as Standard*    
  $0.20, prompts <= 200k tokens    
  $0.40, prompts > 200k    
  $4.50 / 1,000,000 tokens per hour (storage price)

  ---

  * Grounding with Google Search{% sup %}*{% /sup %}
  * Not available{% sup %}**{% /sup %}
  * 5,000 free search requests per month (shared across all Gemini 3 and newer models),
  then $14 per 1,000 requests (subject to a [daily cap](/docs/pricing#pricing-for-tools) of 1,500 requests per day).

  ---

  * Grounding with Google Maps
  * Not available{% sup %}**{% /sup %}
  * 5,000 requests per month (free, shared across all Gemini 3 and newer models), then $14 / 1,000
  search queries.

  ---

  * Used to improve our products
  * Not available
  * [No](/docs/terms)
  {% /table %}

  {% sup %}*{% /sup %} A customer-submitted request to Gemini may result in one or
    more queries to Google Search. You will be charged for each individual search
    query performed.

  {% sup %}**{% /sup %} Can be tested in Google AI Studio.
    

  {% /tab %}

  {% tab title="Priority" %}
  {% table %}
  * Feature
  * Free Tier
  * Paid Tier, per 1M tokens in USD

  ---

  * Input price
  * Not available
  * $3.60, prompts <= 200k tokens    
  $7.20, prompts > 200k tokens

  ---

  * Output price (including thinking tokens)
  * Not available
  * $21.60, prompts <= 200k tokens    
  $32.40, prompts > 200k

  ---

  * Context caching price
  * Not available
  * $0.36, prompts <= 200k tokens    
  $0.72, prompts > 200k    
  $8.10 / 1,000,000 tokens per hour (storage price)

  ---

  * Grounding with Google Search{% sup %}*{% /sup %}
  * Not available{% sup %}**{% /sup %}
  * 5,000 free search requests per month (shared across all Gemini 3 and newer models),
  then $14 per 1,000 requests (subject to a [daily cap](/docs/pricing#pricing-for-tools) of 1,500 requests per day).

  ---

  * Grounding with Google Maps
  * Not available{% sup %}**{% /sup %}
  * 5,000 requests per month (free, shared across all Gemini 3 and newer models), then $14 / 1,000
  search queries.

  ---

  * Used to improve our products
  * Not available
  * [No](/docs/terms)
  {% /table %}

  {% sup %}*{% /sup %} A customer-submitted request to Gemini may result in one or
    more queries to Google Search. You will be charged for each individual search
    query performed.

  {% sup %}**{% /sup %} Can be tested in Google AI Studio.
    

  {% /tab %}

  {% tab title="Contributor" %}
  {% callout type="note" %}
  The Gemini API Contributor Tier is offered as a private preview on an
      invite-only basis. Speed and reliability are equivalent to
      [Standard Tier inference](/docs/optimization). Eligible users will be invited by
      email and see a callout in AI Studio.

  {% /callout %}

  {% table %}
  * Feature
  * Free Tier
  * Paid Tier, per 1M tokens in USD{% sup %}*{% /sup %}

  ---

  * Input price
  * Not available
  * $1.00, prompts <= 200k tokens    
  $2.00, prompts > 200k tokens

  ---

  * Output price (including thinking tokens)
  * Not available
  * $6.00, prompts <= 200k tokens    
  $9.00, prompts > 200k tokens

  ---

  * Context caching price
  * Not available
  * $0.10, prompts <= 200k tokens    
  $0.20, prompts > 200k tokens    
  $4.50 / 1,000,000 tokens per hour (storage price)

  ---

  * Used to improve our products
  * Not available
  * [Yes](/docs/logs-policy#contributor-tier)
  {% /table %}

  {% sup %}*{% /sup %} Discounts and model availability are subject to change.
    

  {% /tab %}

{% /tabs %}

## Gemini Nano Banana 2.1 🍌  {% id="gemini-nano-banana-2.1" %}

{% two-column-layout %}
  {% left-column class="center-vertically" %}
  *[`gemini-nano-banana-2.1`](/docs/models/gemini-nano-banana-2.1)*

  {% /left-column %}

  {% right-column class="center-vertically right-align" %}
  {% button href="https://aistudio.google.com/prompts/new_chat?model=gemini-nano-banana-2.1" variant="ais" %}
  Try it in Google AI Studio

  {% /button %}

  {% /right-column %}

{% /two-column-layout %}

{% hr /%}

An update to Nano Banana 2 (Gemini 3.1 Flash Image), built for high-efficiency
image generation and conversational editing with improved visual quality,
multi-turn character consistency, accurate text rendering, and search-grounded
generation across 1K, 2K, and 4K resolutions.

{% tabs %}
  {% tab title="Standard" %}
  {% table %}
  * Feature
  * Free Tier
  * Paid Tier, per 1M tokens in USD

  ---

  * Input price
  * Not available
  * $1.50 (text/image/video)

  ---

  * Output price
  * Not available
  * $7.50 (text and thinking)    
  $30.00 (images)    
  Equivalent to $0.0336 per 1K image{% sup /%},    
  $0.0504 per 2K image{% sup /%},    
  and $0.113 per 4K image{% sup %}*{% /sup %}.

  ---

  * Grounding with Google Web and Image Search{% sup %}**{% /sup %}
  * Not available
  * 5,000 free search requests per month (shared across all Gemini 3 and newer models),
  then $14 per 1,000 requests for text and image-based grounding (subject to a [daily cap](/docs/pricing#pricing-for-tools) of 1,500 requests per day).

  ---

  * Used to improve our products
  * [Yes](/docs/terms)
  * [No](/docs/terms)
  {% /table %}

  {% /tab %}

  {% tab title="Batch" %}
  {% table %}
  * Feature
  * Free Tier
  * Paid Tier, per 1M tokens in USD

  ---

  * Input price
  * Not available
  * $0.75 (text/image/video)

  ---

  * Output price
  * Not available
  * $3.75 (text and thinking)    
  $15.00 (images)    
  Equivalent to $0.0168 per 1K image{% sup /%},    
  $0.0252 per 2K image{% sup /%},    
  and $0.0567 per 4K image{% sup %}*{% /sup %}.

  ---

  * Used to improve our products
  * [Yes](/docs/terms)
  * [No](/docs/terms)
  {% /table %}

  {% /tab %}

{% /tabs %}

{% sup %}*{% /sup %} Image output is priced at $30 per 1,000,000 tokens
(Standard) and $15 per 1,000,000 tokens (Batch). Output images at 1K
(1024x1024px) consume 1120 tokens and are equivalent to $0.0336 per image.
Output images at 2K (2048x2048px) consume 1680 tokens and are equivalent to
$0.0504 per image. Output images at 4K (4096x4096px) consume 3780 tokens and are
equivalent to $0.113 per image.

{% sup %}**{% /sup %} A customer-submitted request to Gemini may result in one
or more queries to Google Search. You will be charged for each individual search
query performed. Retrieved context (text or images) provided by Grounding with
Google Search is not charged as input tokens.

## Gemini 3.1 Flash Image (Nano Banana 2) 🍌  {% id="gemini-3.1-flash-image" %}

{% two-column-layout %}
  {% left-column class="center-vertically" %}
  *[`gemini-3.1-flash-image`](/docs/models/gemini-3.1-flash-image)*

  {% /left-column %}

  {% right-column class="center-vertically right-align" %}
  {% button href="https://aistudio.google.com/prompts/new_chat?model=gemini-3.1-flash-image" variant="ais" %}
  Try it in Google AI Studio

  {% /button %}

  {% /right-column %}

{% /two-column-layout %}

{% hr /%}

Designed for speed and efficiency, the Gemini 3.1 Flash Image generation model
is effective for quick, interactive responses and high throughput.

{% tabs %}
  {% tab title="Standard" %}
  {% table %}
  * Feature
  * Free Tier
  * Paid Tier, per 1M tokens in USD

  ---

  * Input price
  * Not available
  * $0.50 (text/image)

  ---

  * Output price
  * Not available
  * $3 (text and thinking)    
  $60.00 (images)    
  Equivalent to $0.045 per 0.5K image{% sup /%}    
  $0.067 per 1K image{% sup /%},    
  $0.101 per 2K image{% sup /%},    
  and $0.151 per 4K image{% sup /%}.

  ---

  * Grounding with Google Web and Image Search{% sup %}**{% /sup %}
  * Not available{% sup %}**{% /sup %}
  * 5,000 free search requests per month (shared across all Gemini 3 and newer models),
  then $14 per 1,000 requests for text and image-based grounding (subject to a [daily cap](/docs/pricing#pricing-for-tools) of 1,500 requests per day).

  ---

  * Used to improve our products
  * [Yes](/docs/terms)
  * [No](/docs/terms)
  {% /table %}

  {% /tab %}

{% /tabs %}

{% sup %}*{% /sup %} Image output is priced at $60 per 1,000,000 tokens. Output
images at 0.5K (512px) consume 747 tokens and are equivalent to $0.045 per
image. Output images at 1K (1024x1024px) consume 1120 tokens and are equivalent
to $0.067 per image. Output images at 2K (2048x2048px) consume 1680 tokens and
are equivalent to $0.101 per image. Output images at 4K (4096x4096px) consume
2520 tokens and are equivalent to $0.151 per image.

## Gemini 3.1 Flash Lite Image (Nano Banana 2 Lite) 🍌  {% id="gemini-3.1-flash-lite-image" %}

{% two-column-layout %}
  {% left-column class="center-vertically" %}
  *[`gemini-3.1-flash-lite-image`](/docs/models/gemini-3.1-flash-lite-image)*

  {% /left-column %}

  {% right-column class="center-vertically right-align" %}
  {% button href="https://aistudio.google.com/prompts/new_chat?model=gemini-3.1-flash-lite-image" variant="ais" %}
  Try it in Google AI Studio

  {% /button %}

  {% /right-column %}

{% /two-column-layout %}

{% hr /%}

Designed as the efficiency specialist of the image generation family, the Gemini
3.1 Flash Lite Image model is designed for ultra-low latency and cost-effective
image generation and editing.

{% tabs %}
  {% tab title="Standard" %}
  {% table %}
  * Feature
  * Free Tier
  * Paid Tier, per 1M tokens in USD

  ---

  * Input price
  * Not available
  * $0.25 (text/image/video)

  ---

  * Output price
  * Not available
  * $1.50 (text and thinking)    
  $30.00 (images)    
  Equivalent to $0.0336 per 1K resolution image{% sup %}*{% /sup %}

  ---

  * Used to improve our products
  * [Yes](/docs/terms)
  * [No](/docs/terms)
  {% /table %}

  {% /tab %}

  {% tab title="Batch" %}
  {% table %}
  * Feature
  * Free Tier
  * Paid Tier, per 1M tokens in USD

  ---

  * Input price
  * Not available
  * $0.125 (text/image/video)

  ---

  * Output price
  * Not available
  * $0.75 (text and thinking)    
  $15.00 (images)    
  Equivalent to $0.0168 per 1K resolution image{% sup %}*{% /sup %}

  ---

  * Used to improve our products
  * [Yes](/docs/terms)
  * [No](/docs/terms)
  {% /table %}

  {% /tab %}

{% /tabs %}

{% sup %}*{% /sup %} Image output is priced at $30 per 1,000,000 tokens. Output
images at 1K (1024x1024px) consume 1120 tokens and are equivalent to $0.0336 per
image.

## Gemini 3.8 Flash TTS  {% id="gemini-3.8-flash-tts" %}

{% two-column-layout %}
  {% left-column %}
  *[`gemini-3.8-flash-tts`](/docs/models/gemini-3.8-flash-tts)*

  {% /left-column %}

  {% right-column %}
  {% button class="right-align" href="https://aistudio.google.com/prompts/new_chat?model=gemini-3.8-flash-tts" variant="ais" %}
  Try it in Google AI Studio

  {% /button %}

  {% /right-column %}

{% /two-column-layout %}

{% hr /%}

Our 3.8 Flash Text-to-Speech audio model engineered for studio-grade voice fidelity, expressive acting, and long-form stability.

{% tabs %}
  {% tab title="Standard" %}
  {% table %}
  * Feature
  * Free Tier
  * Paid Tier, per 1M tokens in USD

  ---

  * Input price
  * Free of charge
  * $0.50 (text) through December 31, 2026.   
  $1.00 (text) starting January 1, 2027.

  ---

  * Output price
  * Free of charge
  * $9.00 (audio) through December 31, 2026.   
  $18.00 (audio) starting January 1, 2027.   
  Equivalent to $0.00225 per 10s audio{% sup /%} through December 31, 2026.   
  Equivalent to $0.0045 per 10s audio{% sup /%} starting January 1, 2027.

  ---

  * Used to improve our products
  * [Yes](/docs/terms)
  * [No](/docs/terms)
  {% /table %}

  {% /tab %}

  {% tab title="Batch" %}
  {% table %}
  * Feature
  * Free Tier
  * Paid Tier, per 1M tokens in USD

  ---

  * Input price
  * Not available
  * $0.25 (text) through December 31, 2026.   
  $0.50 (text) starting January 1, 2027.

  ---

  * Output price
  * Not available
  * $4.50 (audio) through December 31, 2026.   
  $9.00 (audio) starting January 1, 2027.   
  Equivalent to $0.001125 per 10s audio{% sup /%} through December 31, 2026.   
  Equivalent to $0.00225 per 10s audio{% sup /%} starting January 1, 2027.

  ---

  * Used to improve our products
  * [Yes](/docs/terms)
  * [No](/docs/terms)
  {% /table %}

  {% /tab %}

  {% tab title="Flex" %}
  {% table %}
  * Feature
  * Free Tier
  * Paid Tier, per 1M tokens in USD

  ---

  * Input price
  * Not available
  * $0.25 (text) through December 31, 2026.   
  $0.50 (text) starting January 1, 2027.

  ---

  * Output price
  * Not available
  * $4.50 (audio) through December 31, 2026.   
  $9.00 (audio) starting January 1, 2027.   
  Equivalent to $0.001125 per 10s audio{% sup /%} through December 31, 2026.   
  Equivalent to $0.00225 per 10s audio{% sup /%} starting January 1, 2027.

  ---

  * Used to improve our products
  * [Yes](/docs/terms)
  * [No](/docs/terms)
  {% /table %}

  {% /tab %}

  {% tab title="Priority" %}
  {% table %}
  * Feature
  * Free Tier
  * Paid Tier, per 1M tokens in USD

  ---

  * Input price
  * Free of charge
  * $0.90 (text) through December 31, 2026.   
  $1.80 (text) starting January 1, 2027.

  ---

  * Output price
  * Free of charge
  * $16.20 (audio) through December 31, 2026.   
  $32.40 (audio) starting January 1, 2027.   
  Equivalent to $0.00405 per 10s audio{% sup /%} through December 31, 2026.   
  Equivalent to $0.0081 per 10s audio{% sup /%} starting January 1, 2027.

  ---

  * Used to improve our products
  * [Yes](/docs/terms)
  * [No](/docs/terms)
  {% /table %}

  {% /tab %}

{% /tabs %}

{% sup %}*{% /sup %} Audio tokens correspond to 25 tokens per second of audio.

## Gemini 3.8 Flash-Lite TTS  {% id="gemini-3.8-flash-lite-tts" %}

{% two-column-layout %}
  {% left-column %}
  *[`gemini-3.8-flash-lite-tts`](/docs/models/gemini-3.8-flash-lite-tts)*

  {% /left-column %}

  {% right-column %}
  {% button class="right-align" href="https://aistudio.google.com/prompts/new_chat?model=gemini-3.8-flash-lite-tts" variant="ais" %}
  Try it in Google AI Studio

  {% /button %}

  {% /right-column %}

{% /two-column-layout %}

{% hr /%}

Our 3.8 Flash-Lite Text-to-Speech audio model optimized for high-throughput, low-latency, and cost-efficient conversational speech.

{% tabs %}
  {% tab title="Standard" %}
  {% table %}
  * Feature
  * Free Tier
  * Paid Tier, per 1M tokens in USD

  ---

  * Input price
  * Free of charge
  * $0.50 (text) through December 31, 2026.   
  $1.00 (text) starting January 1, 2027.

  ---

  * Output price
  * Free of charge
  * $6.00 (audio) through December 31, 2026.   
  $12.00 (audio) starting January 1, 2027.   
  Equivalent to $0.0015 per 10s audio{% sup /%} through December 31, 2026.   
  Equivalent to $0.003 per 10s audio{% sup /%} starting January 1, 2027.

  ---

  * Used to improve our products
  * [Yes](/docs/terms)
  * [No](/docs/terms)
  {% /table %}

  {% /tab %}

  {% tab title="Batch" %}
  {% table %}
  * Feature
  * Free Tier
  * Paid Tier, per 1M tokens in USD

  ---

  * Input price
  * Not available
  * $0.25 (text) through December 31, 2026.   
  $0.50 (text) starting January 1, 2027.

  ---

  * Output price
  * Not available
  * $3.00 (audio) through December 31, 2026.   
  $6.00 (audio) starting January 1, 2027.   
  Equivalent to $0.00075 per 10s audio{% sup /%} through December 31, 2026.   
  Equivalent to $0.0015 per 10s audio{% sup /%} starting January 1, 2027.

  ---

  * Used to improve our products
  * [Yes](/docs/terms)
  * [No](/docs/terms)
  {% /table %}

  {% /tab %}

  {% tab title="Flex" %}
  {% table %}
  * Feature
  * Free Tier
  * Paid Tier, per 1M tokens in USD

  ---

  * Input price
  * Not available
  * $0.25 (text) through December 31, 2026.   
  $0.50 (text) starting January 1, 2027.

  ---

  * Output price
  * Not available
  * $3.00 (audio) through December 31, 2026.   
  $6.00 (audio) starting January 1, 2027.   
  Equivalent to $0.00075 per 10s audio{% sup /%} through December 31, 2026.   
  Equivalent to $0.0015 per 10s audio{% sup /%} starting January 1, 2027.

  ---

  * Used to improve our products
  * [Yes](/docs/terms)
  * [No](/docs/terms)
  {% /table %}

  {% /tab %}

  {% tab title="Priority" %}
  {% table %}
  * Feature
  * Free Tier
  * Paid Tier, per 1M tokens in USD

  ---

  * Input price
  * Free of charge
  * $0.90 (text) through December 31, 2026.   
  $1.80 (text) starting January 1, 2027.

  ---

  * Output price
  * Free of charge
  * $10.80 (audio) through December 31, 2026.   
  $21.60 (audio) starting January 1, 2027.   
  Equivalent to $0.0027 per 10s audio{% sup /%} through December 31, 2026.   
  Equivalent to $0.0054 per 10s audio{% sup /%} starting January 1, 2027.

  ---

  * Used to improve our products
  * [Yes](/docs/terms)
  * [No](/docs/terms)
  {% /table %}

  {% /tab %}

{% /tabs %}

{% sup %}*{% /sup %} Audio tokens correspond to 25 tokens per second of audio.

## Gemini 3.1 Flash TTS Preview  {% id="gemini-3.1-flash-tts-preview" %}

{% two-column-layout %}
  {% left-column class="center-vertically" %}
  *[`gemini-3.1-flash-tts-preview`](/docs/models/gemini-3.1-flash-tts-preview)*

  {% /left-column %}

  {% right-column class="center-vertically right-align" %}
  {% button href="https://aistudio.google.com/prompts/new_chat?model=gemini-3.1-flash-tts-preview" variant="ais" %}
  Try it in Google AI Studio

  {% /button %}

  {% /right-column %}

{% /two-column-layout %}

{% hr /%}

Our 3.1 Flash Text-to-Speech audio model optimized for price-performant,
low-latency, controllable speech generation.

{% tabs %}
  {% tab title="Standard" %}
  {% table %}
  * Feature
  * Free Tier
  * Paid Tier, per 1M tokens in USD

  ---

  * Input price
  * Free of charge
  * $1.00 (text)

  ---

  * Output price
  * Free of charge
  * $20.00 (audio)

  ---

  * Used to improve our products
  * [Yes](/docs/terms)
  * [No](/docs/terms)
  {% /table %}

  {% /tab %}

  {% tab title="Batch" %}
  {% table %}
  * Feature
  * Free Tier
  * Paid Tier, per 1M tokens in USD

  ---

  * Input price
  * Not available
  * $0.50 (text)

  ---

  * Output price
  * Not available
  * $10.00 (audio)

  ---

  * Used to improve our products
  * [Yes](/docs/terms)
  * [No](/docs/terms)
  {% /table %}

  {% /tab %}

{% /tabs %}

{% sup %}*{% /sup %} Audio tokens correspond to 25 tokens per second of audio.

## Gemini 3 Flash Preview  {% id="gemini-3-flash-preview" %}

{% two-column-layout %}
  {% left-column class="center-vertically" %}
  *[`gemini-3-flash-preview`](/docs/models/gemini-3-flash-preview)*

  {% /left-column %}

  {% right-column class="center-vertically right-align" %}
  {% button href="https://aistudio.google.com?model=gemini-3-flash-preview" variant="ais" %}
  Try it in Google AI Studio

  {% /button %}

  {% /right-column %}

{% /two-column-layout %}

{% hr /%}

Our legacy Flash model, providing baseline speed and intelligence.

{% tabs %}
  {% tab title="Standard" %}
  {% table %}
  * Feature
  * Free Tier
  * Paid Tier, per 1M tokens in USD

  ---

  * Input price
  * Free of charge
  * $0.50 (text / image / video)    
  $1.00 (audio)

  ---

  * Output price (including thinking tokens)
  * Free of charge
  * $3.00

  ---

  * Context caching price
  * Free of charge
  * $0.05 (text / image / video)    
  $0.10 (audio)    
  $1.00 / 1,000,000 tokens per hour (storage price)

  ---

  * Grounding with Google Search{% sup %}*{% /sup %}
  * Not available{% sup %}**{% /sup %}
  * 5,000 free search requests per month (shared across all Gemini 3 and newer models),
  then $14 per 1,000 requests (subject to a [daily cap](/docs/pricing#pricing-for-tools) of 1,500 requests per day).

  ---

  * Grounding with Google Maps
  * Not available{% sup %}**{% /sup %}
  * 5,000 requests per month (free, shared across all Gemini 3 and newer models), then $14 / 1,000
  search queries.

  ---

  * Used to improve our products
  * [Yes](/docs/terms)
  * [No](/docs/terms)
  {% /table %}

  {% /tab %}

  {% tab title="Batch" %}
  {% table %}
  * Feature
  * Free Tier
  * Paid Tier, per 1M tokens in USD

  ---

  * Input price
  * Not available
  * $0.25 (text / image / video)    
  $0.50 (audio)

  ---

  * Output price (including thinking tokens)
  * Not available
  * $1.50

  ---

  * Context caching price
  * Not available
  * *Same as Standard*    
  $0.05 (text / image / video)    
  $0.10 (audio)    
  $1.00 / 1,000,000 tokens per hour (storage price)

  ---

  * Grounding with Google Search{% sup %}*{% /sup %}
  * Not available{% sup %}**{% /sup %}
  * 5,000 free search requests per month (shared across all Gemini 3 and newer models),
  then $14 per 1,000 requests (subject to a [daily cap](/docs/pricing#pricing-for-tools) of 1,500 requests per day).

  ---

  * Grounding with Google Maps
  * Not available{% sup %}**{% /sup %}
  * 5,000 requests per month (free, shared across all Gemini 3 and newer models), then $14 / 1,000
  search queries.

  ---

  * Used to improve our products
  * [Yes](/docs/terms)
  * [No](/docs/terms)
  {% /table %}

  {% /tab %}

  {% tab title="Flex" %}
  {% table %}
  * Feature
  * Free Tier
  * Paid Tier, per 1M tokens in USD

  ---

  * Input price
  * Not available
  * $0.25 (text / image / video)    
  $0.50 (audio)

  ---

  * Output price (including thinking tokens)
  * Not available
  * $1.50

  ---

  * Context caching price
  * Not available
  * *Same as Standard*    
  $0.05 (text / image / video)    
  $0.10 (audio)    
  $1.00 / 1,000,000 tokens per hour (storage price)

  ---

  * Grounding with Google Search{% sup %}*{% /sup %}
  * Not available{% sup %}**{% /sup %}
  * 5,000 free search requests per month (shared across all Gemini 3 and newer models),
  then $14 per 1,000 requests (subject to a [daily cap](/docs/pricing#pricing-for-tools) of 1,500 requests per day).

  ---

  * Grounding with Google Maps
  * Not available{% sup %}**{% /sup %}
  * 5,000 requests per month (free, shared across all Gemini 3 and newer models), then $14 / 1,000
  search queries.

  ---

  * Used to improve our products
  * [Yes](/docs/terms)
  * [No](/docs/terms)
  {% /table %}

  {% /tab %}

  {% tab title="Priority" %}
  {% table %}
  * Feature
  * Free Tier
  * Paid Tier, per 1M tokens in USD

  ---

  * Input price
  * Free of charge
  * $0.90 (text / image / video)    
  $1.80 (audio)

  ---

  * Output price (including thinking tokens)
  * Free of charge
  * $5.40

  ---

  * Context caching price
  * Free of charge
  * $0.09 (text / image / video)    
  $0.18 (audio)    
  $1.80 / 1,000,000 tokens per hour (storage price)

  ---

  * Grounding with Google Search{% sup %}*{% /sup %}
  * Not available{% sup %}**{% /sup %}
  * 5,000 free search requests per month (shared across all Gemini 3 and newer models),
  then $14 per 1,000 requests (subject to a [daily cap](/docs/pricing#pricing-for-tools) of 1,500 requests per day).

  ---

  * Grounding with Google Maps
  * Not available{% sup %}**{% /sup %}
  * 5,000 requests per month (free, shared across all Gemini 3 and newer models), then $14 / 1,000
  search queries.

  ---

  * Used to improve our products
  * [Yes](/docs/terms)
  * [No](/docs/terms)
  {% /table %}

  {% /tab %}

{% /tabs %}

{% sup %}*{% /sup %} A customer-submitted request to Gemini may result in one or
more queries to Google Search. You will be charged for each individual search
query performed.

{% sup %}**{% /sup %} Can be tested in Google AI Studio.

## Gemini 3 Pro Image (Nano Banana Pro) 🍌  {% id="gemini-3-pro-image" %}

{% two-column-layout %}
  {% left-column class="center-vertically" %}
  *[`gemini-3-pro-image`](/docs/models/gemini-3-pro-image)*

  {% /left-column %}

  {% right-column class="center-vertically right-align" %}
  {% button href="https://aistudio.google.com/prompts/new_chat?model=gemini-3-pro-image" variant="ais" %}
  Try it in Google AI Studio

  {% /button %}

  {% /right-column %}

{% /two-column-layout %}

{% hr /%}

Our native image generation model, optimized for speed, flexibility, and
contextual understanding. **Text input and output** is priced the same as
[Gemini 3.1 Pro](/docs/pricing#gemini-3.1-pro-preview).

{% tabs %}
  {% tab title="Standard" %}
  {% table %}
  * Feature
  * Free Tier
  * Paid Tier, per 1M tokens in USD

  ---

  * Input price
  * Not available
  * $2.00 (text/image),    
  equivalent to $0.0011 per image{% sup %}*{% /sup %}

  ---

  * Output price
  * Not available
  * $12.00 (text and thinking)    
  $120.00 (images)    
  Equivalent to $0.134 per 1K/2K image{% sup /%}    
  and $0.24 per 4K image{% sup /%}

  ---

  * Grounding with Google Search{% sup %}***{% /sup %}
  * Not available{% sup %}****{% /sup %}
  * 5,000 free search requests per month (shared across all Gemini 3 and newer models),
  then $14 per 1,000 requests (subject to a [daily cap](/docs/pricing#pricing-for-tools) of 1,500 requests per day).

  ---

  * Used to improve our products
  * N/A
  * [No](/docs/terms)
  {% /table %}

  {% /tab %}

{% /tabs %}

{% sup %}*{% /sup %} Image input is set at 560 tokens or $0.0011 per image.

{% sup %}**{% /sup %} Image output is priced at $120 per 1,000,000 tokens.
Output images from 1024x1024px (1K) and up to 2048x2048px (2K) consume 1120
tokens and are equivalent to $0.134 per image. Output images up to 4096x4096px
(4K) consume 2000 tokens and are equivalent to $0.24 per image.

{% sup %}***{% /sup %} A customer-submitted request to Gemini may result in one
or more queries to Google Search. You will be charged for each individual search
query performed.

{% sup %}****{% /sup %} Can be tested in Google AI Studio.

## Gemini 2.5 Pro  {% id="gemini-2.5-pro" %}

*[`gemini-2.5-pro`](/docs/models/gemini-2.5-pro)*

{% hr /%}

{% callout type="caution" %}
  Gemini 2.5 Pro (`gemini-2.5-pro`) is
  [deprecated](/docs/deprecations#gemini-2.5-pro-models) and is no longer
  available to select in Google AI Studio. Effective December 1, 2026, all API
  requests to `gemini-2.5-pro` will automatically route to
  [Gemini 3.8 Flash (`gemini-3.8-flash`)](/docs/models/gemini-3.8-flash) and be
  billed at [Gemini 3.8 Flash rates](/docs/pricing#gemini-3.8-flash).

{% /callout %}

A Pro model which excels at coding and complex reasoning tasks.

{% tabs %}
  {% tab title="Standard" %}
  {% table %}
  * Feature
  * Free Tier
  * Paid Tier, per 1M tokens in USD

  ---

  * Input price
  * Free of charge
  * $1.25, prompts <= 200k tokens    
  $2.50, prompts > 200k tokens

  ---

  * Output price (including thinking tokens)
  * Free of charge
  * $10.00, prompts <= 200k tokens    
  $15.00, prompts > 200k

  ---

  * Context caching price
  * Not available
  * $0.125, prompts <= 200k tokens    
  $0.25, prompts > 200k    
  $4.50 / 1,000,000 tokens per hour (storage price)

  ---

  * Grounding with Google Search
  * Not available
  * 1,500 RPD (free), then $35 / 1,000 grounded prompts

  ---

  * Grounding with Google Maps
  * Not available
  * 10,000 RPD (free), then $25 / 1,000 grounded prompts

  ---

  * Used to improve our products
  * [Yes](/docs/terms)
  * [No](/docs/terms)
  {% /table %}

  {% /tab %}

  {% tab title="Batch" %}
  {% table %}
  * Feature
  * Free Tier
  * Paid Tier, per 1M tokens in USD

  ---

  * Input price
  * Not available
  * $0.625, prompts <= 200k tokens    
  $1.25, prompts > 200k tokens

  ---

  * Output price (including thinking tokens)
  * Not available
  * $5.00, prompts <= 200k tokens    
  $7.50, prompts > 200k

  ---

  * Context caching price
  * Not available
  * $0.125, prompts <= 200k tokens    
  $0.25, prompts > 200k    
  $4.50 / 1,000,000 tokens per hour (storage price)

  ---

  * Grounding with Google Search
  * Not available
  * 1,500 RPD (free), then $35 / 1,000 grounded prompts

  ---

  * Grounding with Google Maps
  * Not available
  * Not available

  ---

  * Used to improve our products
  * [Yes](/docs/terms)
  * [No](/docs/terms)
  {% /table %}

  {% /tab %}

  {% tab title="Flex" %}
  {% table %}
  * Feature
  * Free Tier
  * Paid Tier, per 1M tokens in USD

  ---

  * Input price
  * Not available
  * $0.625, prompts <= 200k tokens    
  $1.25, prompts > 200k tokens

  ---

  * Output price (including thinking tokens)
  * Not available
  * $5.00, prompts <= 200k tokens    
  $7.50, prompts > 200k

  ---

  * Context caching price
  * Not available
  * $0.125, prompts <= 200k tokens    
  $0.25, prompts > 200k    
  $4.50 / 1,000,000 tokens per hour (storage price)

  ---

  * Grounding with Google Search
  * Not available
  * 1,500 RPD (free), then $35 / 1,000 grounded prompts

  ---

  * Grounding with Google Maps
  * Not available
  * Not available

  ---

  * Used to improve our products
  * [Yes](/docs/terms)
  * [No](/docs/terms)
  {% /table %}

  {% /tab %}

  {% tab title="Priority" %}
  {% table %}
  * Feature
  * Free Tier
  * Paid Tier, per 1M tokens in USD

  ---

  * Input price
  * Free of charge
  * $2.25, prompts <= 200k tokens    
  $4.50, prompts > 200k tokens

  ---

  * Output price (including thinking tokens)
  * Free of charge
  * $18.00, prompts <= 200k tokens    
  $27.00, prompts > 200k

  ---

  * Context caching price
  * Not available
  * $0.225, prompts <= 200k tokens    
  $0.45, prompts > 200k    
  $8.10 / 1,000,000 tokens per hour (storage price)

  ---

  * Grounding with Google Search
  * Not available
  * 1,500 RPD (free), then $35 / 1,000 grounded prompts

  ---

  * Grounding with Google Maps
  * Not available
  * 10,000 RPD (free), then $25 / 1,000 grounded prompts

  ---

  * Used to improve our products
  * [Yes](/docs/terms)
  * [No](/docs/terms)
  {% /table %}

  {% /tab %}

{% /tabs %}

## Gemini 2.5 Flash  {% id="gemini-2.5-flash" %}

*[`gemini-2.5-flash`](/docs/models/gemini-2.5-flash)*

{% hr /%}

{% callout type="caution" %}
  Gemini 2.5 Flash (`gemini-2.5-flash`) is
  [deprecated](/docs/deprecations#gemini-2.5-flash-models) and is no longer
  available to select in Google AI Studio. Effective December 1, 2026, all API
  requests to `gemini-2.5-flash` will automatically route to
  [Gemini 3.5 Flash-Lite (`gemini-3.5-flash-lite`)](/docs/models/gemini-3.5-flash-lite)
  and be billed at
  [Gemini 3.5 Flash-Lite rates](/docs/pricing#gemini-3.5-flash-lite).

{% /callout %}

Our first hybrid reasoning model which supports a 1M token context window and
has thinking budgets.

{% tabs %}
  {% tab title="Standard" %}
  {% table %}
  * Feature
  * Free Tier
  * Paid Tier, per 1M tokens in USD

  ---

  * Input price
  * Free of charge
  * $0.30 (text / image / video)    
  $1.00 (audio)

  ---

  * Output price (including thinking tokens)
  * Free of charge
  * $2.50

  ---

  * Context caching price
  * Not available
  * $0.03 (text / image / video)    
  $0.1 (audio)    
  $1.00 / 1,000,000 tokens per hour (storage price)

  ---

  * Grounding with Google Search
  * Free of charge, up to 500 RPD (limit shared with Flash-Lite RPD)
  * 1,500 RPD (free, limit shared with Flash-Lite RPD), then $35 / 1,000
  grounded prompts

  ---

  * Grounding with Google Maps
  * 500 RPD
  * 1,500 RPD (free), then $25 / 1,000 grounded prompts

  ---

  * Used to improve our products
  * [Yes](/docs/terms)
  * [No](/docs/terms)
  {% /table %}

  {% /tab %}

  {% tab title="Batch" %}
  {% table %}
  * Feature
  * Free Tier
  * Paid Tier, per 1M tokens in USD

  ---

  * Input price
  * Not available
  * $0.15 (text / image / video)    
  $0.50 (audio)

  ---

  * Output price (including thinking tokens)
  * Not available
  * $1.25

  ---

  * Context caching price
  * Not available
  * $0.03 (text / image / video)    
  $0.1 (audio)    
  $1.00 / 1,000,000 tokens per hour (storage price)

  ---

  * Grounding with Google Search
  * Not available
  * 1,500 RPD (free, limit shared with Flash-Lite RPD), then $35 / 1,000
  grounded prompts

  ---

  * Grounding with Google Maps
  * Not available
  * Not available

  ---

  * Used to improve our products
  * [Yes](/docs/terms)
  * [No](/docs/terms)
  {% /table %}

  {% /tab %}

  {% tab title="Flex" %}
  {% table %}
  * Feature
  * Free Tier
  * Paid Tier, per 1M tokens in USD

  ---

  * Input price
  * Not available
  * $0.15 (text / image / video)    
  $0.50 (audio)

  ---

  * Output price (including thinking tokens)
  * Not available
  * $1.25

  ---

  * Context caching price
  * Not available
  * $0.03 (text / image / video)    
  $0.1 (audio)    
  $1.00 / 1,000,000 tokens per hour (storage price)

  ---

  * Grounding with Google Search
  * Not available
  * 1,500 RPD (free, limit shared with Flash-Lite RPD), then $35 / 1,000
  grounded prompts

  ---

  * Grounding with Google Maps
  * Not available
  * Not available

  ---

  * Used to improve our products
  * [Yes](/docs/terms)
  * [No](/docs/terms)
  {% /table %}

  {% /tab %}

  {% tab title="Priority" %}
  {% table %}
  * Feature
  * Free Tier
  * Paid Tier, per 1M tokens in USD

  ---

  * Input price
  * Free of charge
  * $0.54 (text / image / video)    
  $1.80 (audio)

  ---

  * Output price (including thinking tokens)
  * Free of charge
  * $4.50

  ---

  * Context caching price
  * Not available
  * $0.054 (text / image / video)    
  $0.18 (audio)    
  $1.80 / 1,000,000 tokens per hour (storage price)

  ---

  * Grounding with Google Search
  * Free of charge, up to 500 RPD (limit shared with Flash-Lite RPD)
  * 1,500 RPD (free, limit shared with Flash-Lite RPD), then $35 / 1,000
  grounded prompts

  ---

  * Grounding with Google Maps
  * 500 RPD
  * 1,500 RPD (free), then $25 / 1,000 grounded prompts

  ---

  * Used to improve our products
  * [Yes](/docs/terms)
  * [No](/docs/terms)
  {% /table %}

  {% /tab %}

{% /tabs %}

## Gemini 2.5 Flash-Lite  {% id="gemini-2.5-flash-lite" %}

{% two-column-layout %}
  {% left-column class="center-vertically" %}
  *[`gemini-2.5-flash-lite`](/docs/models/gemini-2.5-flash-lite)*

  {% /left-column %}

  {% right-column class="center-vertically right-align" %}
  {% button href="https://aistudio.google.com?model=gemini-2.5-flash-lite" variant="ais" %}
  Try it in Google AI Studio

  {% /button %}

  {% /right-column %}

{% /two-column-layout %}

{% hr /%}

A small and cost effective model, built for at scale usage.

{% tabs %}
  {% tab title="Standard" %}
  {% table %}
  * Feature
  * Free Tier
  * Paid Tier, per 1M tokens in USD

  ---

  * Input price (text, image, video)
  * Free of charge
  * $0.10 (text / image / video)    
  $0.30 (audio)

  ---

  * Output price (including thinking tokens)
  * Free of charge
  * $0.40

  ---

  * Context caching price
  * Not available
  * $0.01 (text / image / video)    
  $0.03 (audio)    
  $1.00 / 1,000,000 tokens per hour (storage price)

  ---

  * Grounding with Google Search
  * Free of charge, up to 500 RPD (limit shared with Flash RPD)
  * 1,500 RPD (free, limit shared with Flash RPD), then $35 / 1,000 grounded
  prompts

  ---

  * Grounding with Google Maps
  * 500 RPD
  * 1,500 RPD (free), then $25 / 1,000 grounded prompts

  ---

  * Used to improve our products
  * [Yes](/docs/terms)
  * [No](/docs/terms)
  {% /table %}

  {% /tab %}

  {% tab title="Batch" %}
  {% table %}
  * Feature
  * Free Tier
  * Paid Tier, per 1M tokens in USD

  ---

  * Input price (text, image, video)
  * Not available
  * $0.05 (text / image / video)    
  $0.15 (audio)

  ---

  * Output price (including thinking tokens)
  * Not available
  * $0.20

  ---

  * Context caching price
  * Not available
  * $0.01 (text / image / video)    
  $0.03 (audio)    
  $1.00 / 1,000,000 tokens per hour (storage price)

  ---

  * Grounding with Google Search
  * Not available
  * 1,500 RPD (free, limit shared with Flash RPD), then $35 / 1,000 grounded
  prompts

  ---

  * Grounding with Google Maps
  * Not available
  * Not available

  ---

  * Used to improve our products
  * [Yes](/docs/terms)
  * [No](/docs/terms)
  {% /table %}

  {% /tab %}

  {% tab title="Flex" %}
  {% table %}
  * Feature
  * Free Tier
  * Paid Tier, per 1M tokens in USD

  ---

  * Input price (text, image, video)
  * Not available
  * $0.05 (text / image / video)    
  $0.15 (audio)

  ---

  * Output price (including thinking tokens)
  * Not available
  * $0.20

  ---

  * Context caching price
  * Not available
  * $0.01 (text / image / video)    
  $0.03 (audio)    
  $1.00 / 1,000,000 tokens per hour (storage price)

  ---

  * Grounding with Google Search
  * Not available
  * 1,500 RPD (free, limit shared with Flash RPD), then $35 / 1,000 grounded
  prompts

  ---

  * Grounding with Google Maps
  * Not available
  * Not available

  ---

  * Used to improve our products
  * [Yes](/docs/terms)
  * [No](/docs/terms)
  {% /table %}

  {% /tab %}

  {% tab title="Priority" %}
  {% table %}
  * Feature
  * Free Tier
  * Paid Tier, per 1M tokens in USD

  ---

  * Input price (text, image, video)
  * Free of charge
  * $0.18 (text / image / video)    
  $0.54 (audio)

  ---

  * Output price (including thinking tokens)
  * Free of charge
  * $0.72

  ---

  * Context caching price
  * Not available
  * $0.018 (text / image / video)    
  $0.054 (audio)    
  $1.80 / 1,000,000 tokens per hour (storage price)

  ---

  * Grounding with Google Search
  * Free of charge, up to 500 RPD (limit shared with Flash RPD)
  * 1,500 RPD (free, limit shared with Flash RPD), then $35 / 1,000 grounded
  prompts

  ---

  * Grounding with Google Maps
  * 500 RPD
  * 1,500 RPD (free), then $25 / 1,000 grounded prompts

  ---

  * Used to improve our products
  * [Yes](/docs/terms)
  * [No](/docs/terms)
  {% /table %}

  {% /tab %}

{% /tabs %}

## Gemini 2.5 Flash Native Audio (Live API)  {% id="gemini-2.5-flash-native-audio" %}

{% two-column-layout %}
  {% left-column class="center-vertically" %}
  *[`gemini-2.5-flash-native-audio-preview-12-2025`](/docs/models/gemini-2.5-flash-native-audio-preview-12-2025)*

  {% /left-column %}

  {% right-column class="center-vertically right-align" %}
  {% button href="https://aistudio.google.com/app/live#gemini-2.5-flash-native-audio-preview-12-2025" variant="ais" %}
  Try it in Google AI Studio

  {% /button %}

  {% /right-column %}

{% /two-column-layout %}

{% hr /%}

Our [Live API](/docs/live-api) native audio models optimized for higher quality
audio outputs with better pacing, voice naturalness, verbosity, and mood.

{% table %}
  * Feature
  * Free Tier
  * Paid Tier, per 1M tokens in USD

  ---

  * Input price
  * Free of charge
  * $0.50 (text)    
    $3.00 (audio / video)

  ---

  * Output price (including thinking tokens)
  * Free of charge
  * $2.00 (text)    
    $12.00 (audio)

  ---

  * Used to improve our products
  * [Yes](/docs/terms)
  * [No](/docs/terms)
{% /table %}

## Gemini 2.5 Flash Image (Nano Banana) 🍌  {% id="gemini-2.5-flash-image" %}

{% two-column-layout %}
  {% left-column class="center-vertically" %}
  *[`gemini-2.5-flash-image`](/docs/models/gemini-2.5-flash-image)*

  {% /left-column %}

  {% right-column class="center-vertically right-align" %}
  {% button href="https://aistudio.google.com?model=gemini-2.5-flash-image" variant="ais" %}
  Try it in Google AI Studio

  {% /button %}

  {% /right-column %}

{% /two-column-layout %}

{% hr /%}

{% callout type="warning" %}
   **Warning:** Gemini 2.5 Flash Image
  (`gemini-2.5-flash-image`) is [deprecated](/docs/deprecations) and will be shut
  down on March 15, 2027; migrate to
  [Gemini 3.1 Flash Lite Image](/docs/models/gemini-3.1-flash-lite-image) to avoid
  service disruption. 

{% /callout %}

A native image generation model, optimized for speed, flexibility, and
contextual understanding. Text input and output is priced the same as [2.5
Flash](/docs/pricing#gemini-2.5-flash).

{% tabs %}
  {% tab title="Standard" %}
  {% table %}
  * Feature
  * Free Tier
  * Paid Tier, per 1M tokens in USD

  ---

  * Input price
  * Not available
  * $0.30 (text / image)

  ---

  * Output price
  * Not available
  * $0.039 per image{% sup %}*{% /sup %}

  ---

  * Used to improve our products
  * [Yes](/docs/terms)
  * [No](/docs/terms)
  {% /table %}

  {% /tab %}

  {% tab title="Batch" %}
  {% table %}
  * Feature
  * Free Tier
  * Paid Tier, per 1M tokens in USD

  ---

  * Input price
  * Not available
  * $0.15 (text / image)

  ---

  * Output price
  * Not available
  * $0.0195 per image{% sup %}*{% /sup %}

  ---

  * Used to improve our products
  * [Yes](/docs/terms)
  * [No](/docs/terms)
  {% /table %}

  {% /tab %}

  {% tab title="Flex" %}
  {% table %}
  * Feature
  * Free Tier
  * Paid Tier, per 1M tokens in USD

  ---

  * Input price
  * Not available
  * $0.15 (text / image)

  ---

  * Output price
  * Not available
  * $0.0195 per image{% sup %}*{% /sup %}

  ---

  * Used to improve our products
  * [Yes](/docs/terms)
  * [No](/docs/terms)
  {% /table %}

  {% /tab %}

  {% tab title="Priority" %}
  {% table %}
  * Feature
  * Free Tier
  * Paid Tier, per 1M tokens in USD

  ---

  * Input price
  * Not available
  * $0.54 (text / image)

  ---

  * Output price
  * Not available
  * $0.0702 per image{% sup %}*{% /sup %}

  ---

  * Used to improve our products
  * [Yes](/docs/terms)
  * [No](/docs/terms)
  {% /table %}

  {% /tab %}

{% /tabs %}

{% sup %}*{% /sup %} Image output is priced at $30 per 1,000,000 tokens. Output
images up to 1024x1024px consume 1290 tokens and are equivalent to $0.039 per
image.

## Gemini 2.5 Flash Preview TTS  {% id="gemini-2.5-flash-preview-tts" %}

{% two-column-layout %}
  {% left-column class="center-vertically right-align" %}
  *[`gemini-2.5-flash-preview-tts`](/docs/models/gemini-2.5-flash-preview-tts)*

  {% /left-column %}

  {% right-column %}
  {% button href="https://aistudio.google.com/generate-speech" variant="ais" %}
  Try it in Google AI Studio

  {% /button %}

  {% /right-column %}

{% /two-column-layout %}

{% hr /%}

Our 2.5 Flash text-to-speech audio model optimized for price-performant,
low-latency, controllable speech generation.

{% tabs %}
  {% tab title="Standard" %}
  {% table %}
  * Feature
  * Free Tier
  * Paid Tier, per 1M tokens in USD

  ---

  * Input price
  * Free of charge
  * $0.50 (text)

  ---

  * Output price
  * Free of charge
  * $10.00 (audio)

  ---

  * Used to improve our products
  * [Yes](/docs/terms)
  * [No](/docs/terms)
  {% /table %}

  {% /tab %}

  {% tab title="Batch" %}
  {% table %}
  * Feature
  * Free Tier
  * Paid Tier, per 1M tokens in USD

  ---

  * Input price
  * Not available
  * $0.25 (text)

  ---

  * Output price
  * Not available
  * $5.00 (audio)

  ---

  * Used to improve our products
  * [Yes](/docs/terms)
  * [No](/docs/terms)
  {% /table %}

  {% /tab %}

{% /tabs %}

## Gemini 2.5 Pro Preview TTS  {% id="gemini-2.5-pro-preview-tts" %}

{% two-column-layout %}
  {% left-column class="center-vertically right-align" %}
  *[`gemini-2.5-pro-preview-tts`](/docs/models/gemini-2.5-pro-preview-tts)*

  {% /left-column %}

  {% right-column %}
  {% button href="https://aistudio.google.com/generate-speech" variant="ais" %}
  Try it in Google AI Studio

  {% /button %}

  {% /right-column %}

{% /two-column-layout %}

{% hr /%}

Our 2.5 Pro text-to-speech audio model optimized for powerful, low-latency
speech generation for more natural outputs and easier to steer prompts.

{% tabs %}
  {% tab title="Standard" %}
  {% table %}
  * Feature
  * Free Tier
  * Paid Tier, per 1M tokens in USD

  ---

  * Input price
  * Not available
  * $1.00 (text)

  ---

  * Output price
  * Not available
  * $20.00 (audio)

  ---

  * Used to improve our products
  * [Yes](/docs/terms)
  * [No](/docs/terms)
  {% /table %}

  {% /tab %}

  {% tab title="Batch" %}
  {% table %}
  * Feature
  * Free Tier
  * Paid Tier, per 1M tokens in USD

  ---

  * Input price
  * Not available
  * $0.50 (text)

  ---

  * Output price
  * Not available
  * $10.00 (audio)

  ---

  * Used to improve our products
  * [Yes](/docs/terms)
  * [No](/docs/terms)
  {% /table %}

  {% /tab %}

{% /tabs %}

## Lyria 3.5  {% id="lyria-3-5" %}

*[`lyria-3.5`](/docs/models/lyria-3.5)*

{% hr /%}

Google's music generation model.

{% table %}
  * Feature
  * Free Tier
  * Paid Tier, per request in USD

  ---

  * Lyria 3.5 (Full Song)
  * Not available
  * $0.08 per song

  ---

  * Used to improve our products
  * [Yes](/docs/terms)
  * [No](/docs/terms)
{% /table %}

## Lyria 3  {% id="lyria-3" %}

*[`lyria-3-clip-preview`](/docs/models/lyria-3-clip-preview) and
[`lyria-3-pro-preview`](/docs/models/lyria-3-pro-preview)*

{% hr /%}

Google's family of legacy music generation models.

{% table %}
  * Feature
  * Free Tier
  * Paid Tier, per request in USD

  ---

  * Lyria 3 Clip Preview (30s)
  * Not available
  * $0.04 per song

  ---

  * Lyria 3 Pro Preview (Full Song)
  * Not available
  * $0.08 per song

  ---

  * Used to improve our products
  * [Yes](/docs/terms)
  * [No](/docs/terms)
{% /table %}

## Gemini Embedding 2  {% id="gemini-embedding-2" %}

{% two-column-layout %}
  {% left-column class="center-vertically" %}
  *[`gemini-embedding-2`](/docs/models/gemini-embedding-2)*

  {% /left-column %}

  {% right-column class="center-vertically right-align" %}
  {% button href="/docs/embeddings" variant="ais" %} Try the
      API
      {% /button %}

  {% /right-column %}

{% /two-column-layout %}

{% hr /%}

Our first multimodal embedding model, mapping text, images, video, audio, and
PDFs into a unified embedding space.

{% tabs %}
  {% tab title="Standard" %}
  {% table %}
  * Feature
  * Free Tier
  * Paid Tier, per 1M tokens in USD

  ---

  * Text input price
  * Free of charge
  * $0.20

  ---

  * Image input price
  * Free of charge
  * $0.45 ($0.00012 per image)

  ---

  * Audio input price
  * Free of charge
  * $6.50 ($0.00016 per second)

  ---

  * Video input price
  * Free of charge
  * $12.00 ($0.00079 per frame)

  ---

  * Used to improve our products
  * [Yes](/docs/terms)
  * [No](/docs/terms)
  {% /table %}

  {% /tab %}

  {% tab title="Batch" %}
  {% table %}
  * Feature
  * Free Tier
  * Paid Tier, per 1M tokens in USD

  ---

  * Text input price
  * Not available
  * $0.10

  ---

  * Image input price
  * Not available
  * $0.225 ($0.00006 per image)

  ---

  * Audio input price
  * Not available
  * $3.25 ($0.00008 per second)

  ---

  * Video input price
  * Not available
  * $6.00 ($0.000395 per frame)

  ---

  * Used to improve our products
  * [Yes](/docs/terms)
  * [No](/docs/terms)
  {% /table %}

  {% /tab %}

{% /tabs %}

## Gemini Embedding  {% id="gemini-embedding" %}

{% two-column-layout %}
  {% left-column class="center-vertically" %}
  *[`gemini-embedding-001`](/docs/models/gemini-embedding-001)*

  {% /left-column %}

  {% right-column class="center-vertically right-align" %}
  {% button href="/docs/embeddings" variant="ais" %} Try the
      API
      {% /button %}

  {% /right-column %}

{% /two-column-layout %}

{% hr /%}

Our first Gemini Embeddings model for text-only use cases.

{% tabs %}
  {% tab title="Standard" %}
  {% table %}
  * Feature
  * Free Tier
  * Paid Tier, per 1M tokens in USD

  ---

  * Input price
  * Free of charge
  * $0.15

  ---

  * Used to improve our products
  * [Yes](/docs/terms)
  * [No](/docs/terms)
  {% /table %}

  {% /tab %}

  {% tab title="Batch" %}
  {% table %}
  * Feature
  * Free Tier
  * Paid Tier, per 1M tokens in USD

  ---

  * Input price
  * Not available
  * $0.075

  ---

  * Used to improve our products
  * [Yes](/docs/terms)
  * [No](/docs/terms)
  {% /table %}

  {% /tab %}

{% /tabs %}

## Gemini Robotics ER 2 Preview  {% id="gemini-robotics-er-2" %}

{% two-column-layout %}
  {% left-column %}
  *[`gemini-robotics-er-2-preview`](/docs/models/gemini-robotics-er-2-preview)*

  {% /left-column %}

  {% right-column %}
  {% button class="right-align" href="https://aistudio.google.com?model=gemini-robotics-er-2-preview" variant="ais" %}
  Try it in Google AI Studio

  {% /button %}

  {% /right-column %}

{% /two-column-layout %}

{% hr /%}

Gemini Robotics ER 2, short for Gemini Robotics Embodied Reasoning 2, is a
vision-language model endpoint that enables robots to understand their environments
precisely, supporting agentic orchestration of robots, video progress
understanding, multi-robot collaboration, and advanced spatial reasoning.

{% tabs %}
  {% tab title="Standard" %}
  {% table %}
  * Feature
  * Free Tier
  * Paid Tier, per 1M tokens in USD

  ---

  * Input price
  * Free of charge
  * $1.00 (text / image / video / audio) through December 31, 2026. \\
  $2.00 (text / image / video / audio) starting January 1, 2027.

  ---

  * Output price (including thinking tokens)
  * Free of charge
  * $5.00 through December 31, 2026. \\
  $10.00 starting January 1, 2027.

  ---

  * Context caching price
  * Not available
  * $0.10 through December 31, 2026. \\
  $0.20 starting January 1, 2027. \\
  $0.50 / 1,000,000 tokens per hour (storage price) through December 31, 2026. \\
  $1.00 / 1,000,000 tokens per hour (storage price) starting January 1, 2027.

  ---

  * Grounding with Google Search
  * Not available
  * 5,000 free search requests per month (shared across all Gemini 3 and newer models), then $14 per 1,000 requests (subject to a [daily cap](/docs/pricing#pricing-for-tools) of 1,500 requests per day).

  ---

  * Used to improve our products
  * [Yes](/docs/terms)
  * [No](/docs/terms)
  {% /table %}

  {% /tab %}

  {% tab title="Batch" %}
  {% table %}
  * Feature
  * Free Tier
  * Paid Tier, per 1M tokens in USD

  ---

  * Input price
  * Not available
  * $0.50 (text / image / video / audio) through December 31, 2026. \\
  $1.00 (text / image / video / audio) starting January 1, 2027.

  ---

  * Output price (including thinking tokens)
  * Not available
  * $2.50 through December 31, 2026. \\
  $5.00 starting January 1, 2027.

  ---

  * Context caching price
  * Not available
  * $0.05 through December 31, 2026. \\
  $0.10 starting January 1, 2027. \\
  $0.50 / 1,000,000 tokens per hour (storage price) through December 31, 2026. \\
  $1.00 / 1,000,000 tokens per hour (storage price) starting January 1, 2027.

  ---

  * Grounding with Google Search
  * Not available
  * 5,000 free search requests per month (shared across all Gemini 3 and newer models), then $14 per 1,000 requests (subject to a [daily cap](/docs/pricing#pricing-for-tools) of 1,500 requests per day).

  ---

  * Used to improve our products
  * [Yes](/docs/terms)
  * [No](/docs/terms)
  {% /table %}

  {% /tab %}

{% /tabs %}

## Gemini Robotics ER 2 Streaming Preview  {% id="gemini-robotics-er-2-streaming" %}

{% two-column-layout %}
  {% left-column %}
  *[`gemini-robotics-er-2-streaming-preview`](/docs/models/gemini-robotics-er-2-streaming-preview)*

  {% /left-column %}

  {% right-column %}
  {% button class="right-align" href="https://aistudio.google.com?model=gemini-robotics-er-2-streaming-preview" variant="ais" %}
  Try it in Google AI Studio

  {% /button %}

  {% /right-column %}

{% /two-column-layout %}

{% hr /%}

Gemini Robotics ER 2 Streaming is a vision-language model endpoint for robotics
optimized for real-time text streaming using the Live API. It accepts text,
image, video, and audio input and supports bidirectional streaming with
function calling.

{% tabs %}
  {% tab title="Standard" %}
  {% table %}
  * Feature
  * Free Tier
  * Paid Tier, per 1M tokens in USD

  ---

  * Input price
  * Free of charge
  * $1.00 (text / image / video / audio) through December 31, 2026. \\
  $2.00 (text / image / video / audio) starting January 1, 2027.

  ---

  * Output price
  * Free of charge
  * $5.00 through December 31, 2026. \\
  $10.00 starting January 1, 2027.

  ---

  * Grounding with Google Search
  * Not available
  * 5,000 free search requests per month (shared across all Gemini 3 and newer models), then $14 per 1,000 requests (subject to a [daily cap](/docs/pricing#pricing-for-tools) of 1,500 requests per day).

  ---

  * Used to improve our products
  * [Yes](/docs/terms)
  * [No](/docs/terms)
  {% /table %}

  {% /tab %}

{% /tabs %}

## [Gemma 4](https://ai.google.dev/gemma/docs/core/model_card_4) {% id="gemma-4" %}

{% hr /%}

Our lightweight, state-of the art, open model built from the same technology
that powers our Gemini models.

{% table %}
  * Feature
  * Free Tier
  * Paid Tier, per 1M tokens in USD

  ---

  * Input price
  * Free of charge
  * Not available

  ---

  * Output price
  * Free of charge
  * Not available

  ---

  * Context caching price
  * Free of charge
  * Not available

  ---

  * Context caching (storage)
  * Free of charge
  * Not available

  ---

  * Tuning price
  * Not available
  * Not available

  ---

  * Grounding with Google Search
  * Not available
  * Not available

  ---

  * Used to improve our products
  * [Yes](/docs/terms)
  * [No](/docs/terms)
{% /table %}

## Pricing for tools  {% id="pricing-for-tools" %}

Tools are priced at their own rates, applied to the model using them. Check the
[Models](/docs/models) page for which tools are available to each model.

{% table %}
  * Feature
  * Free Tier
  * Paid Tier, per 1M tokens in USD

  ---

  * [Google Search](/docs/google-search#pricing)
  * 500 RPD free (limit shared for Flash and Flash-Lite).    
    Not available for Pro.
  * Gemini 2.5 models:    
    1,500 RPD free (limit shared for Flash and Flash-Lite).    
    Then $35 / 1,000 grounded prompts    
    Gemini 3 and newer models:    
    5,000 free search requests per month (shared across all Gemini 3 and newer
    models), then $14 per 1,000 requests. (Subject to a default daily cap of
    1,500 requests per day (RPD) per project on the Gemini Developer API.)

  ---

  * [Google Maps](/docs/maps-grounding#pricing-and-rate-limits)
  * 500 RPD    
    Not available for Pro.
  * Gemini 2.5 models:    
    1,500 RPD free (limit shared for Flash and Flash-Lite)    
    10,000 RPD free for Pro.    
    Then $25 / 1,000 grounded prompts    
    Gemini 3 and newer models:    
    5,000 requests per month (free, shared across all Gemini 3 and newer models), then
    $14 / 1,000 search queries.

  ---

  * [Code execution](/docs/code-execution#billing)
  * Free of charge
  * Code execution is billed at the standard token rates for the selected model.
      
    Costs are determined solely by tool usage; no charges accrue for session    
    runtime. Generated code and execution results are billed as **Output    
    tokens** when created, and as **Input tokens** when used by the model in    
    its iterative reasoning process.

  ---

  * [URL context](/docs/url-context#limitations)
  * Free of charge
  * Charged as input tokens per model pricing.

  ---

  * [Computer use](/docs/computer-use)
  * Not available
  * Charged as regular tokens per model pricing (e.g., standard [Gemini 3.8 Flash](/docs/pricing#gemini-3.8-flash) pricing).

  ---

  * [File search](/docs/file-search#pricing)
  * Free of charge
  * Charged for embeddings at [Gemini Embedding](/docs/pricing#gemini-embedding)
    ($0.15 / 1M tokens) or
    [Gemini Embedding 2](/docs/pricing#gemini-embedding-2) rates.   
    Retrieved document tokens charged as regular tokens per model pricing.

  ---

  * [Custom Tools endpoint (Gemini 3.1 Pro Preview)](/docs/models/gemini-3.1-pro-preview)
  * Not available
  * Same as [Gemini 3.1 Pro Preview](/docs/pricing#gemini-3.1-pro-preview)
    pricing
{% /table %}

## Pricing for agents  {% id="pricing-for-agents" %}

Agent usage costs are calculated based on the underlying token consumption and
usage of the tools.

{% table %}
  * Feature
  * Model
  * Tools

  ---

  * [Gemini Deep Research agent](/docs/deep-research)
  * All model inference is charged at standard Gemini list rates, including
    input,    
    output, and intermediate input / reasoning tokens generated during agentic    
    loops.
  * Tool usage fees apply per existing pricing structure, maintaining standard   
    distinctions for Search Grounding (retrieved tokens excluded) versus    
    Url_context / File Search (retrieved tokens included in all other tools).

  ---

  * [Managed agents in Gemini API](/docs/agents)
  * All model inference is charged at standard Gemini list rates, including
    input,    
    output, and intermediate input / reasoning tokens generated during agentic    
    loops. (See [pricing details](/docs/agents#pricing)).
  * Environment compute (CPU, memory, sandbox execution) is not billed during
    the preview period.

  ---

  * [Antigravity Agent](/docs/antigravity-agent)
  * All model inference is charged at standard Gemini list rates, including
    input,    
    output, and intermediate input / reasoning tokens generated during agentic    
    loops. (See [pricing details](/docs/agents#pricing)).
  * Environment compute (CPU, memory, sandbox execution) is not billed during
    the    
    preview period.
{% /table %}

## Notes  {% id="notes" %}

*     **Agentic video understanding:** When using agentic video understanding,
  token usage is variable based on the content loaded by the model rather than
  full video length. This typically results in up to 88% fewer input tokens
  for long-form video, though token counts depend on query complexity and
  dynamic sampling depth (which may exceed 1 FPS for detailed visual
  segments). See [Agentic video
  understanding](/docs/video-understanding#agentic-video-understanding).

*     **Document token billing:** Tokens for the `DOCUMENT` modality (for example,
  PDFs) are billed at the image token rate. In API responses, these tokens
  appear under the `DOCUMENT` modality within `promptTokensDetails`.

*     Google AI Studio usage is free of charge in all [available
  regions](/docs/available-regions). See [Billing FAQs](/docs/billing) for
  details.

*     Prices may differ from the prices listed here and the prices offered on
  Gemini Enterprise Agent Platform. For Gemini Enterprise Agent Platform
  prices, see the [Gemini Enterprise Agent Platform pricing
  page](https://cloud.google.com/products/gemini-enterprise-agent-platform).

*     If you are using [dynamic retrieval](/docs/google-search) to optimize costs,
  only requests that contain at least one grounding support URL from the web
  in their response are charged for Grounding with Google Search. Costs for
  Gemini always apply. Rate limits are subject to change.

*     **Search Grounding rate limits:** On the Gemini Developer API, Grounding
  with Google Search on Gemini 3 and newer models is subject to a default
  daily rate limit of 1,500 requests per day (RPD) per project across all paid
  tiers, resetting daily at midnight Pacific Time. For high-volume production
  workloads requiring higher daily limits, consider using
  [Vertex AI](https://cloud.google.com/vertex-ai/generative-ai/docs/grounding/grounding-with-google-search#considerations),
  which provides a default quota of 1,000,000 search queries per day.


